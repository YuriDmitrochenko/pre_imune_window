# The interactive bench

`epithelium_bench.html` is a self-contained JavaScript implementation of the same model
as the Python runners. It is a single file with no build step and no dependencies: open
it in a browser and it runs. It exists for exploration — watching the sheet, inflicting
wounds by hand, sweeping a parameter and seeing where the behaviour turns over — not for
producing the paper's statistics. Nothing in Chapters 1–4 depends on it.

Two files are included:

| File | Contains |
|---|---|
| `epithelium_bench.html` | current build, with the oxygen filter |
| `epithelium_bench_no_o2filter.html` | earlier build, glycogen only; kept because the figures in the bench's own notes were produced with it |

## Using it

Open the file. The sheet starts running. The controls:

- **Pause / Speed** — the speed button cycles 0.6 … 76.8 simulated hours per second.
- **Inflict wound** — removes a disc of cells from the current state. Let the sheet reach
  equilibrium first; the wound is applied on top of whatever is on screen, not from scratch.
- **Recurrent injury, every** — repeated wounding at a fixed interval.
- **Seed one reversion** — converts one random cell to the reverted lineage, instead of
  waiting for the 1/1000 per-division rate to produce one.
- **Full screen** (`F`, `Esc` to leave) — the sheet alone, for watching or recording.
- **Auto-stop** — pauses at the target horizon and writes a text summary.

The caption burned into the frame records the parameters, so a saved frame or a recording
documents the run it came from.

### Parameters used in the paper

| Control | Value | Note |
|---|---|---|
| Reverted glycogen store | 1 : 3.0 (`revStore` = 0.33) | slider steps by 0.01 |
| O₂ filter | 40 % (`oxyRev` = 0.40) | slider steps by 0.02 |
| Differentiated lifespan τ | 6 d | |
| Cell cycle | 15 h | |
| Reversion rate | 1 : 1000 per daughter | |
| Niche tolerance | 2.4 h | |

`oxyRev` is a **survival** probability: at every birth of a reverted-lineage cell the engine
draws once, and with probability `oxyRev` the daughter is born as a reverted cell, otherwise
it dies immediately and the `Filtered at birth (O2)` counter advances. `oxyRev = 1.0` turns
the filter off. Note that the slider is labelled "survival at reversion", but the draw is
made at *every* division of the reverted lineage, not only at the reversion event — the
behaviour is the one described in the paper; only the label is imprecise.

## Running it headlessly

The bench advances on `requestAnimationFrame`, so at its fastest setting a 20,000 h horizon
still takes about an hour of wall time. `bench_headless.js` loads the page in headless
Chromium and calls `advance()` in a tight loop instead, covering the same horizon in roughly
seven minutes, and prints the same summary the Auto-stop panel writes:

```
npm i playwright
node bench_headless.js --store 0.33 --oxy 0.40 --hours 20000
```

The bench's script is wrapped in an IIFE, so the driver writes a temporary copy of the page
with one added line exposing `advance()` and friends on `window.__bench`. The engine is not
modified. The bench seeds a fixed LCG at 20260727, so a run repeats exactly; pass `--seed`
to change it.

## Relation to the Python engine

The two implementations share the model, the LCG and the order of random-number-generator
calls, but not the geometry of cell occupancy: the Python runners are the older
one-node-one-cell lattice, while the bench gives each cell a territory of 1–4 nodes and lets
coverage proceed by spreading and shift. **Runs are therefore not expected to match
step-for-step between the two.** They agree on outcomes and disagree on timing. At
`revStore` = 0.33 with the filter off, both end with the reverted clone occupying essentially
the whole sheet (final clone ≈ 3.3–3.4 × 10³ cells), but the bench reaches the establishment
threshold at about 322 h against 792–1272 h in the Python series. Use the Python runners,
not the bench, for anything quantitative.

## A caveat on the notes inside the page

The bench page carries its own "What the run showed" and "Conclusions" sections at the
bottom. They were written against an earlier build and have **not** been re-checked against
the current one. In particular, the τ table and Conclusion 2 state that at τ = 6 d the sheet
settles at 52 % density with cells stretched 1.92-fold; the build shipped here settles at
about 98 % density with a mean cell area of 1.02 under the same parameters. Whatever
produced the 52 % figure, it is not this file. Treat those two passages as unverified until
someone re-runs the τ sweep; the rest of the notes — the feasibility condition
`reserve fraction ≥ T_cycle / τ`, the two-beat account of healing, and the empirical test of
Conclusion 5 — do not depend on that table.
