// Headless driver for epithelium_bench.html.
//
// The bench normally advances on requestAnimationFrame at a few simulated hours
// per second, so a 20,000 h run would take over an hour of wall time. This driver
// loads the page in headless Chromium and calls advance() in a tight loop instead,
// covering the same horizon in about seven minutes.
//
// The bench's script is wrapped in an IIFE, so nothing is reachable from outside.
// The driver therefore writes a temporary copy of the page with one extra line that
// exposes the needed functions on window.__bench. The engine itself is not modified.
//
// Usage:
//   npm i playwright
//   node bench_headless.js [--store 0.33] [--oxy 0.40] [--hours 20000] [--seed 20260727]
//
// The bench uses a fixed LCG seeded at 20260727, so a run is reproducible.
// Sliders are stepped (revStore by 0.01, oxyRev by 0.02); this driver sets both
// values programmatically, so any value in range can be used.

const {chromium} = require('playwright');
const fs = require('fs'), os = require('os'), path = require('path');

const arg = (name, dflt) => {
  const i = process.argv.indexOf('--' + name);
  return i > 0 ? parseFloat(process.argv[i + 1]) : dflt;
};
const store = arg('store', 0.33);
const oxy   = arg('oxy',   0.40);
const hours = arg('hours', 20000);
const seed  = arg('seed',  null);

const SRC  = path.join(__dirname, 'epithelium_bench.html');
const HOOK = 'window.__bench={advance,buildSummaryText,count,reset,'
           + 'get S(){return S},set seedBase(v){seedBase=v}};\n';
const TAIL = 'reset();\nrequestAnimationFrame(loop);\n})();';

(async () => {
  const src = fs.readFileSync(SRC, 'utf8');
  if (!src.includes(TAIL)) throw new Error('bench layout changed; cannot attach hook');
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'bench-')), 'bench.html');
  fs.writeFileSync(tmp, src.replace(TAIL, HOOK + TAIL));

  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.on('pageerror', e => { console.error('page error:', e.message); process.exitCode = 1; });
  await page.route('**fonts.g**', r => r.abort());          // offline: skip webfonts
  await page.goto('file://' + tmp, {waitUntil: 'load'});
  await page.waitForFunction(() => window.__bench);

  await page.evaluate(({store, oxy, seed}) => {
    const B = window.__bench;
    B.S.running = false;        // this driver, not rAF, advances the clock
    B.S.autoStopH = 0;          // stop is handled here
    B.S.revStore = store;
    if ('oxyRev' in B.S) B.S.oxyRev = oxy;
    if (seed !== null) B.seedBase = seed;
    B.reset();
  }, {store, oxy, seed});

  const DT_MIN = 3;                                   // one step = 3 simulated minutes
  const total = Math.round(hours * 60 / DT_MIN);
  const t0 = Date.now();
  for (let done = 0; done < total; ) {
    const n = Math.min(20000, total - done);
    await page.evaluate(k => { const a = window.__bench.advance; for (let i = 0; i < k; i++) a(); }, n);
    done += n;
    const el = (Date.now() - t0) / 1000;
    process.stderr.write(`\r${done}/${total} steps  ${el.toFixed(0)}s  `
                       + `ETA ${(el / done * (total - done)).toFixed(0)}s   `);
  }
  process.stderr.write('\n');

  console.log(await page.evaluate(() => window.__bench.buildSummaryText()));
  await browser.close();
  fs.rmSync(path.dirname(tmp), {recursive: true, force: true});
})();
