# Series S0–S3: extensions the published code supports

These are the simulation series described in Appendix A of the paper. They were **not run**;
the conclusions of Chapters 1, 2 and 4 rest on the 2,500 runs in `data/` alone. They are
documented and supported by `run_batch_missing.py` so that anyone who wants to carry them
out can do so without reconstructing anything.

## Running them

```bash
pip install numba
python run_batch_missing.py S0      # then S1, S2, S3
```

Each series writes two files: `missing_S<n>_runs.csv` (one row per run, same columns as the
published data, plus a few) and `missing_S<n>_traj.csv` (the 24-hour trajectory of clone size
and reverted burden for each run). A series resumes from its own CSV, so an interrupted run
can be continued by launching the same command again. `SESSION_MINUTES = 30` stops launching
new runs after half an hour; raise or remove it for an uninterrupted run.

## Settings shared with the published runs

Horizon 20,000 h; establishment threshold 500 cells in the largest connected reverted cluster,
checked every 24 h; 100 seeds (0–99) per parameter combination; `lifeD` = 6; `pRevert` = 1/1000
per division. Wounding (S3): first wound at 1000 h, defect 200 cells, interval drawn from
{12, 24, 48} h and fixed per seed.

## What differs from the two runners used in the paper

The engine is identical — the same LCG and the same order of random-number-generator calls.
Two things differ in the runner: the trajectory file described above, and a wound interval that
is shared between the bounded and chronic runs of the same seed, giving a paired design. In the
published wound series the two intervals were drawn independently, which is why the bounded and
chronic figures in Chapter 2 differ slightly even where the design makes them equivalent.

## The series

**S0 — reproducibility check (10 runs; run this first).** Five seeds from two published series,
at `revStore` = 0.33, `oxyRev` = 0.40 and 1.0, no wound. The output must match the published
CSVs exactly. Any deviation means the engine is not the one that produced the published data,
and nothing further should be run until it is resolved.

Expected values:

| oxyRev | seed | rev_total | rev_oxy_death | final_clone_size | final_density | established at, h |
|---|---|---|---|---|---|---|
| 0.40 | 0 | 460 | 4892 | 0 | 0.5505 | — |
| 0.40 | 1 | 441 | 3976 | 1 | 0.5440 | — |
| 0.40 | 2 | 474 | 3597 | 6 | 0.5490 | — |
| 0.40 | 3 | 454 | 5350 | 0 | 0.5723 | — |
| 0.40 | 4 | 439 | 5762 | 2 | 0.5533 | — |
| 1.0 | 0 | 28 | 0 | 3353 | 0.5585 | 912 |
| 1.0 | 1 | 32 | 0 | 3382 | 0.5633 | 1272 |
| 1.0 | 2 | 22 | 0 | 3334 | 0.5553 | 1032 |
| 1.0 | 3 | 24 | 0 | 3314 | 0.5520 | 1152 |
| 1.0 | 4 | 24 | 0 | 3361 | 0.5598 | 792 |

**S1 — the missing corner (1,000 runs).** `revStore` = 1.0 (full glycogen) across the whole
oxygen grid {0.30 … 0.60, 1.0}, no wound, plus `revStore` = 0.33 at `oxyRev` 0.55 and 0.60.
This determines whether the oxygen filter is sufficient for containment on its own, without a
reduced glycogen buffer — the question Section 2.6 names as unanswered.

**S2 — the rest of the phase diagram (1,600 runs).** `revStore` = 0.50 and 0.75 across the same
oxygen grid, no wound. Together with S1 and the published `revStore` = 0.33 series this completes
the revStore × oxyRev grid and tests whether the two barriers combine multiplicatively or interact.

**S3 — glycogen under wounding (1,000 runs).** `oxyRev` = 0.50 with `revStore` ∈ {0.20, 0.25,
0.33, 0.50, 1.0}, bounded and chronic, paired wound interval. The 0.33 row repeats a published
point under the paired design.
