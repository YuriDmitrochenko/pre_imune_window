"""Wound series in the three sibling-fate variants (Section 2.6, Table 2.5): per cell, established runs, median time and final clone in A, B and C,
and Fisher P values. Variant A is read from data/derived/master_runs.csv (S3 and the Chapter 2 wound series), B and C from data/siblings/runs_wound_BC.csv.
Run from the repository root:  python code/summarize_wound_BC.py   (writes data/derived/summary_wound_ABC.csv)"""
import csv,statistics as st,collections
from scipy.stats import fisher_exact
rows=list(csv.DictReader(open("data/siblings/runs_wound_BC.csv")))
M=list(csv.DictReader(open("data/derived/master_runs.csv")))
A=[]
for r in M:
    if r['wound_start_h'] in ('','None') or float(r['oxyRev'])>=1.0: continue
    if r['series']=='S3': g='S3w'
    elif 'oxygrid_wound' in r['source_file']: g='OGw'
    else: continue
    A.append(dict(group=g,scenario=r['scenario'],sibMode='0',revStore=r['revStore'],oxyRev=r['oxyRev'],seed=r['seed'],
        clone_established_at_h=r['clone_established_at_h'],final_clone_size=r['final_clone_size'],final_clone_frac=r['final_clone_frac']))
allr=[dict(r,sibMode=str(r['sibMode'])) for r in rows]+A
cell=collections.defaultdict(list)
for r in allr: cell[(r['group'],r['scenario'],round(float(r['revStore']),3),round(float(r['oxyRev']),3),r['sibMode'])].append(r)
est=lambda r:r['clone_established_at_h'] not in ('','None')
def med(v): return st.median(v) if v else None
out=[]
keys=sorted({k[:4] for k in cell},key=lambda k:(k[0],k[1],k[2],k[3]))
for g,sc,rev,oxy in keys:
    d={'group':g,'scenario':sc,'revStore':rev,'oxyRev':oxy,'Ps':round((1+oxy)/2,4)}
    e={}
    for m,l in (('0','A'),('1','B'),('3','C')):
        v=cell[(g,sc,rev,oxy,m)]; ev=[x for x in v if est(x)]
        d['n'+l]=len(v); d['est'+l]=len(ev); d['frac'+l]=len(ev)/len(v)
        d['medT'+l]=med([float(x['clone_established_at_h']) for x in ev])
        d['medClone'+l]=med([float(x['final_clone_size']) for x in v])
        d['medFrac'+l]=med([float(x['final_clone_frac']) for x in v])
        e[l]=(len(ev),len(v))
    for a,b in (('A','B'),('B','C'),('A','C')):
        t=[[e[a][0],e[a][1]-e[a][0]],[e[b][0],e[b][1]-e[b][0]]]
        d['p_'+a+b]=fisher_exact(t)[1]
    out.append(d)
f=list(out[0].keys())
w=csv.DictWriter(open("data/derived/summary_wound_ABC.csv","w",newline=""),fieldnames=f);w.writeheader();w.writerows(out)
