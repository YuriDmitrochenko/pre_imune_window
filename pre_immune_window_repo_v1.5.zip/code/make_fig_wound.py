"""Figure 2.11 (establishment under wounding in variants A, B, C) from data/derived/summary_wound_ABC.csv.
Run from the repository root:  python code/make_fig_wound.py"""
import csv,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=list(csv.DictReader(open("data/derived/summary_wound_ABC.csv")))
def get(g,sc,rev,oxy,l): 
    for x in R:
        if x['group']==g and x['scenario']==sc and abs(float(x['revStore'])-rev)<1e-6 and abs(float(x['oxyRev'])-oxy)<1e-6: return float(x['frac'+l])*100
COL={'A':'#1b6ca8','B':'#e08a00','C':'#b2182b'};MK={'A':'o','B':'s','C':'^'}
T={'en':dict(t1='Oxygen filter at glycogen 0.33',x1='Survival of a reverted cell at division, s',t2='Glycogen reserve at oxyRev = 0.50 (s = 0.75)',x2='Glycogen reserve (revStore)',
  y='Runs with an established clone, %',b='bounded wounding',c='chronic wounding',w='wounding (bounded = chronic)',
  note='Wounding opens the barrier in all three variants; the order A ≥ B ≥ C is kept in every cell'),
 'ru':dict(t1='Кислородный фильтр при гликогене 0,33',x1='Выживание ревертной клетки при делении, s',t2='Запас гликогена при oxyRev = 0,50 (s = 0,75)',x2='Запас гликогена (revStore)',
  y='Прогоны с закрепившимся клоном, %',b='ограниченное ранение',c='хроническое ранение',w='ранение (ограниченное = хроническое)',
  note='Ранение открывает барьер во всех трёх вариантах; порядок A ≥ B ≥ C сохраняется в каждой ячейке')}
def draw(l,fn):
    t=T[l];fig,(a1,a2)=plt.subplots(1,2,figsize=(7.4,3.5),dpi=200)
    oxy=[0.35,0.40,0.45,0.50];xs=[(1+o)/2 for o in oxy]
    for v in 'ABC':
        for sc,ls in (('bounded','-'),('chronic','--')):
            a1.plot(xs,[get('OGw',sc,0.33,o,v) for o in oxy],ls=ls,color=COL[v],marker=MK[v],ms=4.5,lw=1.4,mfc=COL[v] if sc=='bounded' else 'white')
    a1.set_xticks(xs);a1.set_xticklabels([(('%.3f'%x if round(x*1000)%10 else '%.2f'%x)).replace('.',',' if l=='ru' else '.') for x in xs],fontsize=8)
    a1.set_title(t['t1'],fontsize=9);a1.set_xlabel(t['x1'],fontsize=8.5);a1.set_ylabel(t['y'],fontsize=8.5)
    revs=[0.20,0.25,0.33,0.50,1.0]
    for v in 'ABC':
        a2.plot(range(5),[get('S3w','bounded',r,0.5,v) for r in revs],color=COL[v],marker=MK[v],ms=4.5,lw=1.4)
    a2.set_xticks(range(5));a2.set_xticklabels(['0.20','0.25','0.33','0.50','1.0'] if l=='en' else ['0,20','0,25','0,33','0,50','1,0'],fontsize=8)
    a2.set_title(t['t2'],fontsize=9);a2.set_xlabel(t['x2'],fontsize=8.5)
    for a in (a1,a2):
        a.set_ylim(-4,104);a.grid(alpha=.25);a.tick_params(labelsize=8)
        for s in ('top','right'): a.spines[s].set_visible(False)
    h=[plt.Line2D([],[],color=COL[v],marker=MK[v],ms=4.5,lw=1.4,label=v) for v in 'ABC']
    h+=[plt.Line2D([],[],color='#555',lw=1.4,ls='-',marker='o',ms=4.5,label=t['b']),plt.Line2D([],[],color='#555',lw=1.4,ls='--',marker='o',mfc='white',ms=4.5,label=t['c'])]
    a1.legend(handles=h,fontsize=7,loc='upper left',frameon=False)
    a2.text(0.98,0.05,t['w'],transform=a2.transAxes,fontsize=7,color='#555',ha='right')
    fig.tight_layout();fig.savefig(fn);print(fn)
draw('en','figures/fig2_11.png');draw('ru','figures/fig2_11_ru.png')
