"""
Full wound series for the sibling-fate variants B (sibMode 1) and C (sibMode 3).
Repeats, with the same seeds and the same wound intervals, the two wound series that exist for variant A:
  S3w  : revStore {0.20, 0.25, 0.33, 0.50, 1.0} x oxyRev 0.50 x {bounded, chronic} x seeds 0-99 (paired interval per seed)
  OGw  : revStore 0.33 x oxyRev {0.35, 0.40, 0.45, 0.50} x {bounded, chronic} x seeds 0-99 (interval from Random(12345), in order)
Per variant 1,000 + 800 = 1,800 runs; two variants = 3,600 runs.
Wound protocol: first wound at 1000 h, defect 200 cells, interval 12/24/48 h, pRevert 0.001, horizon 20,000 h, threshold 500.
'bounded' stops wounding when the clone first exceeds 500 cells, 'chronic' wounds to the end of the horizon.

Before the main run:  python check_sibmode0.py (must print True), then  python run_wound_BC.py --smoke  (a few minutes).
Main run on two computers (Sara's usual split):
  python run_wound_BC.py --part 1/2 --split 44,56      (computer 1)
  python run_wound_BC.py --part 2/2 --split 44,56      (computer 2)
Output: runs_wound_BC_part<i>of<n>.csv (columns of the earlier runs + sibMode, Ps, mom_death, group).
Resume key (group, scenario, sibMode, revStore, oxyRev, seed): running the same command again continues.
Jobs are dealt seed by seed, so an early stop leaves every cell with the same number of seeds.
"""
import os, sys, csv, time, random
from concurrent.futures import ProcessPoolExecutor, as_completed
import run_batch_siblings as R

SMOKE = '--smoke' in sys.argv
TARGET_HOURS = 60 if SMOKE else 20000
WOUND_START_H = 20 if SMOKE else 1000
WOUND_SIZE = 200
FREQ_CHOICES = [12, 24, 48]
FREQ_DRAW_SEED = 12345
SCENARIOS = ['bounded', 'chronic']
MODES = [1, 3]                       # 1 = B, 3 = C
NSEEDS = 100
S3_REV, S3_OXY = [0.20, 0.25, 0.33, 0.50, 1.0], [0.50]
OG_REV, OG_OXY = [0.33], [0.35, 0.40, 0.45, 0.50]
if SMOKE: NSEEDS = 1

PART, NPARTS, WEIGHTS = 1, 1, None
for i, a in enumerate(sys.argv):
    if a.startswith('--part'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        PART, NPARTS = (int(x) for x in v.split('/'))
    if a.startswith('--split'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        WEIGHTS = [int(x) for x in v.split(',')]
assert 1 <= PART <= NPARTS
if WEIGHTS: assert len(WEIGHTS) == NPARTS and sum(WEIGHTS) == 100

def owner_part(k):
    if WEIGHTS is None: return k % NPARTS
    slot, acc = (k * 37) % 100, 0
    for i, w in enumerate(WEIGHTS):
        acc += w
        if slot < acc: return i

OUT = 'runs_wound_BC_smoke.csv' if SMOKE else 'runs_wound_BC.csv'
if NPARTS > 1: OUT = OUT.replace('.csv', f'_part{PART}of{NPARTS}.csv')

def key(group, scenario, mode, rev, oxy, seed):
    return (group, scenario, int(mode), round(float(rev), 6), round(float(oxy), 6), int(seed))

def build_cells():
    """(group, scenario, revStore, oxyRev, seed, wound_freq_h) for one variant, in the order of the earlier series."""
    cells = []
    for sc in SCENARIOS:                              # S3w: paired interval per seed
        for rev in S3_REV:
            for oxy in S3_OXY:
                for s in range(NSEEDS):
                    f = random.Random(FREQ_DRAW_SEED * 1000003 + s).choice(FREQ_CHOICES)
                    cells.append(('S3w', sc, rev, oxy, s, f))
    rng = random.Random(FREQ_DRAW_SEED)               # OGw: one sequential draw over (scenario, oxyRev, seed)
    for sc in SCENARIOS:
        for oxy in OG_OXY:
            for s in range(100):
                f = rng.choice(FREQ_CHOICES)
                if s < NSEEDS: cells.append(('OGw', sc, OG_REV[0], oxy, s, f))
    return cells

if __name__ == '__main__':
    cells = build_cells()
    cells.sort(key=lambda c: c[4])                    # seed-major (stable), so an early stop is balanced
    allj = [(m,) + c for c in cells for m in MODES]
    print(f'{len(allj)} runs in the whole wound series')
    done = set()
    if os.path.exists(OUT):
        with open(OUT, newline='') as fh:
            for r in csv.DictReader(fh):
                done.add(key(r['group'], r['scenario'], r['sibMode'], r['revStore'], r['oxyRev'], r['seed']))
    jobs = []
    for k, (m, grp, sc, rev, oxy, seed, f) in enumerate(allj):
        if owner_part(k) != PART - 1 or key(grp, sc, m, rev, oxy, seed) in done: continue
        jobs.append((grp, dict(run_id=k + 1, seed=seed, target_hours=TARGET_HOURS, scenario=sc,
                         params=dict(lifeD=6.0, revStore=rev, oxyRev=oxy, pRevert=0.001, sibMode=m, q2=1.0),
                         wound_start_h=WOUND_START_H, wound_freq_h=f, wound_size=WOUND_SIZE, stop_threshold=500)))
    print(f'part {PART}/{NPARTS}: {len(jobs)} runs left; numba={R.HAVE_NUMBA}')
    nw = os.cpu_count() or 1
    t0 = time.time(); writer = None; n = 0
    new = not os.path.exists(OUT) or os.path.getsize(OUT) == 0
    with open(OUT, 'a', newline='') as f, ProcessPoolExecutor(max_workers=nw) as ex:
        for s in range(0, len(jobs), nw):
            futs = {ex.submit(R.run_one, **j): g for g, j in jobs[s:s + nw]}
            for fut in as_completed(futs):
                row = fut.result(); row['Ps'] = (1 + row['oxyRev']) / 2; row['group'] = futs[fut]
                if writer is None:
                    writer = csv.DictWriter(f, fieldnames=list(row.keys()))
                    if new: writer.writeheader()
                writer.writerow(row); f.flush(); n += 1
                print(f"[{n}/{len(jobs)}] {row['group']} {row['scenario']} mode={row.get('sibMode')} rev={row['revStore']} "
                      f"oxy={row['oxyRev']} seed={row['seed']} freq={row['wound_freq_h']} wounds={row['wounds_inflicted']} "
                      f"clone={row['final_clone_size']} est={row['clone_established_at_h']} ({(time.time()-t0)/60:.1f} min)")
    print(f'done: {n} runs in {(time.time()-t0)/60:.1f} min -> {OUT}')
