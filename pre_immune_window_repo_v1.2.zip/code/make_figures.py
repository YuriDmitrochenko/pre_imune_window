import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
U='../data/'
B=pd.read_csv(U+'runs_series_baseline_033_2026-09.csv')
GN=pd.read_csv(U+'runs_series_glycogen_grid_none_2026-09.csv')
GW=pd.read_csv(U+'runs_series_glycogen_grid_wound_2026-09.csv')
ON=pd.read_csv(U+'runs_series_oxygrid_2026-08-29.csv')
OW=pd.read_csv(U+'runs_series_oxygrid_wound_2026-09.csv')
G=pd.concat([GN,GW,B])
C={'none':'#2a78d6','bounded':'#eb6834','chronic':'#1baf7a'}
LAB={'none':'no wound','bounded':'bounded wounding','chronic':'chronic wounding'}
INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.edgecolor':INK2,'axes.labelcolor':INK,
 'xtick.color':INK2,'ytick.color':INK2,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.8,
 'axes.spines.top':False,'axes.spines.right':False,'axes.axisbelow':True,'legend.frameon':False,
 'lines.linewidth':2,'lines.markersize':7,'savefig.dpi':200,'figure.facecolor':'white'})
def save(f,n): f.tight_layout(); f.savefig(f'../figures/{n}.png'); plt.close(f)
SC=['none','bounded','chronic']

# 1.1 cumulative establishment, revStore .33
f,ax=plt.subplots(figsize=(7,3.8)); t=np.arange(0,3001,24)
for i,s in enumerate(SC):
    e=B[B.scenario==s].clone_established_at_h
    y=[(e<=x).mean()*100 for x in t]
    ax.step(t,y,where='post',color=C[s],label=LAB[s],lw=2,ls=['-','--',':'][i])
ax.axvline(1000,color=INK2,lw=1,ls='--'); ax.text(1015,4,'first wound\n(bounded, chronic)',color=INK2,fontsize=8.5)
ax.set_xlabel('Time, h'); ax.set_ylabel('Runs with clone ≥500 cells, %'); ax.set_ylim(0,103); ax.set_xlim(0,3000)
ax.legend(loc='lower right'); save(f,'fig1_1')

# 1.2 final clone size by scenario
f,ax=plt.subplots(figsize=(7,3.6)); rng=np.random.default_rng(1)
for i,s in enumerate(SC):
    v=B[B.scenario==s].final_clone_size.values
    ax.scatter(i+rng.uniform(-.18,.18,len(v)),v,s=9,color=C[s],alpha=.45,lw=0)
    ax.boxplot(v,positions=[i],widths=.5,showfliers=False,medianprops=dict(color=INK,lw=2),
               boxprops=dict(color=INK2),whiskerprops=dict(color=INK2),capprops=dict(color=INK2))
    ax.text(i+.3,np.median(v),f'{np.median(v):.0f}',va='center',fontsize=8.5,color=INK)
ax.set_xticks(range(3),[LAB[s] for s in SC]); ax.set_ylabel('Largest clone at 20,000 h, cells'); ax.grid(axis='x',visible=False)
save(f,'fig1_2')

RS=[0.20,0.25,0.30,0.33]; off={'none':-.004,'bounded':0,'chronic':.004}
def rsplot(fn,ylabel,fname,log=False):
    f,ax=plt.subplots(figsize=(7,3.8))
    for i,s in enumerate(SC):
        y=[fn(G[(G.revStore.round(2)==r)&(G.scenario==s)]) for r in RS]
        ax.plot([r+off[s] for r in RS],y,marker=['o','s','^'][i],color=C[s],label=LAB[s])
    ax.axvspan(0.185,0.225,color='#f1f0ec',zorder=0); pass
    ax.set_xticks(RS,['0.20','0.25','0.30','0.33']); ax.set_xlabel('revStore (glycogen cap of reverted lineage, fraction of normal)')
    ax.set_ylabel(ylabel); ax.set_xlim(0.185,0.34)
    if log: ax.set_yscale('log')
    ax.legend(loc='lower right' if 'Runs' in ylabel else 'upper right'); return f,ax
f,ax=rsplot(lambda d:d.clone_established_at_h.notna().mean()*100,'Runs with clone ≥500 cells, %','fig1_3'); ax.set_ylim(0,105); ax.text(0.205,72,'below the\nbiological\nboundary',fontsize=8,color=INK2,ha='center'); save(f,'fig1_3')
f,ax=rsplot(lambda d:d.clone_established_at_h.median(),'Median time to establishment, h','fig1_4'); ax.set_ylim(0,16000); ax.text(0.205,8000,'below the\nbiological\nboundary',fontsize=8,color=INK2,ha='center'); save(f,'fig1_4')

# 1.5 small multiples final clone size
f,axs=plt.subplots(1,3,figsize=(9,3.4),sharey=True)
for ax,s in zip(axs,SC):
    data=[np.maximum(G[(G.revStore.round(2)==r)&(G.scenario==s)].final_clone_size.values,1) for r in RS]
    for j,v in enumerate(data):
        ax.scatter(j+rng.uniform(-.2,.2,len(v)),v,s=6,color=C[s],alpha=.4,lw=0)
    ax.boxplot(data,positions=range(4),widths=.55,showfliers=False,medianprops=dict(color=INK,lw=2),
               boxprops=dict(color=INK2),whiskerprops=dict(color=INK2),capprops=dict(color=INK2))
    ax.set_yscale('log'); ax.set_xticks(range(4),['0.20','0.25','0.30','0.33']); ax.set_title(LAB[s],fontsize=10,color=INK)
    ax.set_xlabel('revStore'); ax.grid(axis='x',visible=False)
axs[0].set_ylabel('Largest clone at 20,000 h, cells (log)'); save(f,'fig1_5')

OX=[0.30,0.35,0.40,0.45,0.50]
# 2.1
f,ax=plt.subplots(figsize=(7,3.8))
sv=[(ON[ON.oxyRev.round(2)==o].final_clone_size>1).mean()*100 for o in OX]
es=[ON[ON.oxyRev.round(2)==o].clone_established_at_h.notna().mean()*100 for o in OX]
ax.plot(OX,sv,marker='o',color='#2a78d6',label='clone survives (>1 cell)')
ax.plot(OX,es,marker='s',color='#eb6834',label='clone established (≥500 cells)')
for x,y in zip(OX,sv): ax.text(x,y+3,f'{y:.0f}',ha='center',fontsize=8.5,color=INK)
for x,y in zip(OX,es): ax.text(x,y+3,f'{y:.0f}',ha='center',fontsize=8.5,color=INK)
ax.set_xticks(OX); ax.set_xlabel('oxyRev (O₂ filter survival probability at birth)'); ax.set_ylabel('Runs, %'); ax.set_ylim(0,100)
ax.legend(loc='upper left'); save(f,'fig2_1')

# 2.2
f,ax=plt.subplots(figsize=(7,3.8)); w=.26; cols=['#2a78d6','#eb6834','#1baf7a']
st=[('median',lambda v:v.median()),('90th percentile',lambda v:v.quantile(.9)),('maximum',lambda v:v.max())]
for k,(n,fn) in enumerate(st):
    y=[max(fn(ON[ON.oxyRev.round(2)==o].final_clone_size),0.8) for o in OX]
    ax.bar(np.arange(5)+(k-1)*w,y,w-.03,color=cols[k],label=n)
ax.set_yscale('log'); ax.set_ylim(0.7,2000); ax.axhline(500,color=INK2,lw=1,ls='--'); ax.text(3.6,560,'establishment threshold (500)',ha='right',fontsize=8,color=INK2)
ax.set_xticks(range(5),[f'{o:.2f}' for o in OX]); ax.set_xlabel('oxyRev'); ax.set_ylabel('Largest clone at 20,000 h, cells (log)')
ax.legend(loc='upper left',bbox_to_anchor=(0,0.82)); ax.grid(axis='x',visible=False); save(f,'fig2_2')

# 2.3
OXW=[0.35,0.40,0.45,0.50]
f,ax=plt.subplots(figsize=(7,3.8))
for i,s in enumerate(['bounded','chronic']):
    y=[OW[(OW.oxyRev.round(2)==o)&(OW.scenario==s)].clone_established_at_h.notna().mean()*100 for o in OXW]
    ax.plot(OXW,y,marker=['s','^'][i],color=C[s],label=LAB[s])
yn=[ON[ON.oxyRev.round(2)==o].clone_established_at_h.notna().mean()*100 for o in OXW]
ax.plot(OXW,yn,marker='o',color=C['none'],label=LAB['none'])
ax.set_xticks(OXW); ax.set_xlabel('oxyRev'); ax.set_ylabel('Runs with clone ≥500 cells, %'); ax.set_ylim(0,100)
ax.legend(loc='upper left'); save(f,'fig2_3')

# 2.4
f,axs=plt.subplots(1,2,figsize=(9,3.4),sharey=True)
for ax,s in zip(axs,['bounded','chronic']):
    data=[np.maximum(OW[(OW.oxyRev.round(2)==o)&(OW.scenario==s)].final_clone_size.values,1) for o in OXW]
    for j,v in enumerate(data): ax.scatter(j+rng.uniform(-.2,.2,len(v)),v,s=6,color=C[s],alpha=.4,lw=0)
    ax.boxplot(data,positions=range(4),widths=.55,showfliers=False,medianprops=dict(color=INK,lw=2),
               boxprops=dict(color=INK2),whiskerprops=dict(color=INK2),capprops=dict(color=INK2))
    ax.set_yscale('log'); ax.set_xticks(range(4),[f'{o:.2f}' for o in OXW]); ax.set_xlabel('oxyRev'); ax.set_title(LAB[s],fontsize=10,color=INK)
    ax.axhline(500,color=INK2,lw=1,ls='--'); ax.grid(axis='x',visible=False)
axs[0].set_ylabel('Largest clone at 20,000 h, cells (log)'); save(f,'fig2_4')

# 2.5 whole design
xs=[0.30,0.35,0.40,0.45,0.50]; xpos=list(range(5))+[6]
f,ax=plt.subplots(figsize=(7.5,3.9))
for i,s in enumerate(SC):
    ys=[]; xp=[]
    for j,o in enumerate(xs):
        d=ON if s=='none' else OW[OW.scenario==s]
        d=d[d.oxyRev.round(2)==o]
        if len(d): ys.append(d.clone_established_at_h.notna().mean()*100); xp.append(j)
    ax.plot(np.array(xp)+(i-1)*.06,ys,marker=['o','s','^'][i],color=C[s],label=LAB[s])
    yb=B[B.scenario==s].clone_established_at_h.notna().mean()*100
    ax.plot(6+(i-1)*.12,yb,marker=['o','s','^'][i],color=C[s],ls='none',ms=8)
ax.axvline(5.5,color=INK2,lw=1,ls=':')
ax.text(2,104,'O₂ filter on (Chapter 2)',ha='center',color=INK2,fontsize=9); ax.text(6,104,'filter off\n(Chapter 1)',ha='center',color=INK2,fontsize=9)
ax.set_xticks(xpos,['0.30','0.35','0.40','0.45','0.50','1.0']); ax.set_xlabel('oxyRev (revStore = 0.33 throughout)')
ax.set_ylabel('Runs with clone ≥500 cells, %'); ax.set_ylim(0,115); ax.set_xlim(-.5,6.6); ax.legend(loc='center left',bbox_to_anchor=(0,.55))
save(f,'fig2_5')


# --- Figure 4.1 (Chapter 4): niche-loss mortality vs clone size ---
from scipy import stats as _st
d=pd.concat([pd.read_csv(U+'runs_series_oxygrid_wound_2026-09.csv'),
             pd.read_csv(U+'runs_series_oxygrid_2026-08-29.csv')])
d=d[d['oxyRev']<1].copy()
d['rolls']=d['rev_oxy_death']/(1-d['oxyRev']); d['born']=d['rolls']*d['oxyRev']
d=d[d['born']>0]
d['lost']=100*d['rev_lost']/d['born']; d['sz']=d['final_clone_size'].clip(lower=1)
f,ax=plt.subplots(figsize=(7,4))
m=d['sz']>500
ax.scatter(d.loc[~m,'sz'],d.loc[~m,'lost'],s=11,color='#2a78d6',alpha=.35,lw=0,label='clone not established')
ax.scatter(d.loc[m,'sz'],d.loc[m,'lost'],s=11,color='#eb6834',alpha=.45,lw=0,label='clone established (\u2265500)')
for sub,c in [(d[~m],'#2a78d6'),(d[m],'#eb6834')]:
    ax.hlines(sub['lost'].median(),sub['sz'].min(),sub['sz'].max(),color=c,lw=2.5)
ax.annotate('median 10.4%',(2.5,10.4),xytext=(1.3,17),color='#2a78d6',fontsize=9,
            arrowprops=dict(arrowstyle='-',color='#2a78d6',lw=1))
ax.annotate('median 2.1%',(1700,2.1),xytext=(700,0.55),color='#eb6834',fontsize=9,
            arrowprops=dict(arrowstyle='-',color='#eb6834',lw=1))
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('Largest clone at the end of the run, cells (log)')
ax.set_ylabel('Niche-loss deaths per reverted cell\nthat survived the birth filter, %')
ax.axvline(500,color=INK2,lw=1,ls='--'); ax.text(540,26,'establishment threshold',color=INK2,fontsize=8.5)
ax.legend(loc='lower left'); save(f,'fig4_1')
print('median lost_frac: not established %.1f%%, established %.1f%%'%(d[~m]['lost'].median(),d[m]['lost'].median()))
print('Spearman size vs lost_frac: %.3f'%_st.spearmanr(d['sz'],d['lost']).statistic)

# ===== Section 2.6: completed design (series S0-S3 plus published series) =====
import glob
_f=['runs_series_baseline_033_2026-09','runs_series_glycogen_grid_none_2026-09','runs_series_glycogen_grid_wound_2026-09',
    'runs_series_oxygrid_2026-08-29','runs_series_oxygrid_wound_2026-09']
_M=[pd.read_csv(U+f'missing_S{i}_runs.csv') for i in range(4)]
_A=pd.concat([pd.read_csv(U+f+'.csv') for f in _f]+[m for m in _M if m.series.iloc[0]!='S0'])
_A['oxyRev']=_A['oxyRev'].fillna(1.0)
NW=_A[_A.scenario=='none'].copy(); NW['rs']=NW.revStore.round(2); NW['ox']=NW.oxyRev.round(2)
NW=NW.drop_duplicates(['rs','ox','seed'])      # one entry per (revStore, oxyRev, seed)
NW['est']=NW.clone_established_at_h.notna()
RSV=[1.0,0.75,0.50,0.33,0.30,0.25,0.20]; OXV=[0.30,0.35,0.40,0.45,0.50,0.55,0.60,1.0]
pe=NW.groupby(['rs','ox']).est.mean().mul(100).unstack().reindex(index=RSV,columns=OXV)
mt=NW[NW.est].groupby(['rs','ox']).clone_established_at_h.median().unstack().reindex(index=RSV,columns=OXV)
import matplotlib.colors as mc
cm=mc.LinearSegmentedColormap.from_list('c',['#f7f6f2','#E0B21A','#B3231C'])
f,axs=plt.subplots(1,2,figsize=(11,3.9))
for ax,M,ttl,fmt,norm in [(axs[0],pe,'Runs with clone ≥500 cells, %',lambda v:f'{v:.0f}',mc.Normalize(0,100)),
                          (axs[1],mt/1000,'Median time to establishment, 10³ h (established runs only)',lambda v:f'{v:.1f}',mc.LogNorm(0.3,20))]:
    ax.grid(False); ax.imshow(np.ma.masked_invalid(M.values.astype(float)),cmap=cm,norm=norm,aspect='auto')
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v=M.values[i,j]
            ax.text(j,i,'–' if np.isnan(v) else fmt(v),ha='center',va='center',fontsize=8.5,color=INK)
    ax.set_xticks(range(len(OXV)),[f'{o:.2f}' for o in OXV]); ax.set_yticks(range(len(RSV)),[f'{r:.2f}' for r in RSV])
    ax.set_xlabel('oxyRev (birth-filter pass probability; 1.00 = filter off)'); ax.set_title(ttl,fontsize=9.5,color=INK)
    for s in ax.spines.values(): s.set_visible(False)
axs[0].set_ylabel('revStore')
save(f,'fig2_6')

# product law
d=NW[NW.est].groupby(['rs','ox']).agg(n=('est','size'),t=('clone_established_at_h','median')).reset_index()
d=d[d.n>=90]; d['prod']=d.rs*d.ox
X=np.column_stack([np.ones(len(d)),np.log(d.rs),np.log(d.ox)]); y=np.log(d.t)
b=np.linalg.lstsq(X,y,rcond=None)[0]; r2=1-((y-X@b)**2).sum()/((y-y.mean())**2).sum()
print('log t = %.2f %+.2f ln revStore %+.2f ln oxyRev, R2=%.2f, n=%d'%(b[0],b[1],b[2],r2,len(d)))
f,ax=plt.subplots(figsize=(7,4))
sc=ax.scatter(d['prod'],d.t,c=np.log(d.rs),cmap=cm.reversed(),s=34,edgecolor=INK2,lw=.5)
xs=np.logspace(np.log10(d['prod'].min()),0,50); ax.plot(xs,np.exp(b[0])*xs**b[1],color=INK2,ls='--',lw=1.2,label=f'power law, exponent {b[1]:.2f}')
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('revStore × oxyRev'); ax.set_ylabel('Median time to establishment, h')
ax.legend(loc='upper right'); cb=f.colorbar(sc,ax=ax); cb.set_label('ln revStore'); save(f,'fig2_7')

# S3: wounding with active filter (oxyRev = 0.50)
S3=_M[3]; S3=S3.assign(rs=S3.revStore.round(2),est=S3.clone_established_at_h.notna())
f,ax=plt.subplots(figsize=(7,3.8)); RS3=[0.20,0.25,0.33,0.50,1.0]
nn=NW[NW.ox==0.5].groupby('rs').est.mean()*100
ax.plot([r for r in RS3 if r in nn.index],[nn[r] for r in RS3 if r in nn.index],marker='o',color=C['none'],label=LAB['none'])
for i,s in enumerate(['bounded','chronic']):
    g=S3[S3.scenario==s].groupby('rs').est.mean()*100
    ax.plot(RS3,[g[r] for r in RS3],marker=['s','^'][i],color=C[s],label=LAB[s],ls=['--',':'][i])
ax.set_xscale('log'); ax.set_xticks(RS3,['0.20','0.25','0.33','0.50','1.0']); ax.minorticks_off()
ax.set_xlabel('revStore (oxyRev = 0.50)'); ax.set_ylabel('Runs with clone ≥500 cells, %'); ax.set_ylim(-3,105); ax.legend(loc='center right'); save(f,'fig2_8')

# ===== Section 2.6: robustness to the reversion rate (series S4) =====
S4=pd.concat([pd.read_csv(U+'missing_S4A_runs.csv'),pd.read_csv(U+'missing_S4B_runs.csv')])
S4['rs']=S4.revStore.round(2); S4['ox']=S4.oxyRev.round(2); S4['est']=S4.clone_established_at_h.notna()
BASE=NW[NW.rs.isin([0.33,0.50,1.0])&NW.ox.isin([0.30,0.40,0.50,0.60,1.0])&(NW.pRevert.round(5)==0.001)]
BASE=BASE.assign(pRevert=0.001)
PN=[(0.0005,'pRevert = 1/2000 (half)',S4[S4.pRevert.round(5)==0.0005],50),
    (0.001,'pRevert = 1/1000 (base)',BASE,100),
    (0.002,'pRevert = 1/500 (double)',S4[S4.pRevert.round(5)==0.002],50)]
RS4=[1.0,0.50,0.33]; OX4=[0.30,0.40,0.50,0.60,1.0]
f,axs=plt.subplots(1,3,figsize=(11,3.3),sharey=True)
for ax,(pr,ttl,d,n) in zip(axs,PN):
    M4=d.groupby(['rs','ox']).est.mean().mul(100).unstack().reindex(index=RS4,columns=OX4)
    ax.grid(False); ax.imshow(M4.values.astype(float),cmap=cm,norm=mc.Normalize(0,100),aspect='auto')
    for i in range(3):
        for j in range(5): ax.text(j,i,f'{M4.values[i,j]:.0f}',ha='center',va='center',fontsize=9,color=INK)
    ax.set_xticks(range(5),[f'{o:.2f}' for o in OX4]); ax.set_yticks(range(3),[f'{r:.2f}' for r in RS4])
    ax.set_title(f'{ttl}, {n} runs per cell',fontsize=9.5,color=INK); ax.set_xlabel('oxyRev')
    for s in ax.spines.values(): s.set_visible(False)
axs[0].set_ylabel('revStore'); save(f,'fig2_9')
for pr,ttl,d,n in PN:
    g=d[(d.rs==0.33)&(d.ox==0.50)]; print(f'S4 check pRevert={pr}: revStore .33 oxyRev .50: clone>=12 cells {100*(g.final_clone_size>=12).mean():.0f}%')
