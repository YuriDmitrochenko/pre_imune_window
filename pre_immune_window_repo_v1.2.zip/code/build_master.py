"""
build_master.py - merge every run table in ../data/ into ONE table and print/save statistics.

Run from the code/ folder:   python build_master.py
Needs: pandas, numpy (openpyxl only if you want the .xlsx output).

Writes to ../data/derived/ :
  master_runs.csv      one row per run, all series together, with provenance columns
  summary_cells.csv    one row per parameter cell x scenario: n, established %, 95% CI, times, clone sizes
  provenance.csv       which file contributed which runs (the 'what comes from where' table)
  summary_cells.xlsx   the same summary + provenance, as sheets (if openpyxl is installed)
Series S0 (10 runs) repeats published runs as a reproducibility check; it is kept in
master_runs.csv (is_repro_check = True) but left out of every statistic.
"""
import glob, os, numpy as np, pandas as pd

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
OUT = os.path.join(DATA, 'derived'); os.makedirs(OUT, exist_ok=True)

# ---------- 1. read and stack all run tables ----------
files = sorted(f for f in glob.glob(os.path.join(DATA, '*.csv'))
               if '_traj' not in f and os.path.basename(f).startswith(('runs_series', 'missing_')))
parts = []
for f in files:
    d = pd.read_csv(f); d['source_file'] = os.path.basename(f)
    if 'series' not in d.columns:                      # the five published files
        d['series'] = 'published'
    parts.append(d)
M = pd.concat(parts, ignore_index=True)
if 'oxyRev' not in M.columns: M['oxyRev'] = 1.0
M['oxyRev'] = M['oxyRev'].fillna(1.0)                   # filter off in the glycogen-only series
M['pRevert'] = M['pRevert'].fillna(1/1000)

# ---------- 2. derived columns ----------
M['established'] = M['clone_established_at_h'].notna()
M['survived_ge2'] = M['final_clone_size'] >= 2
M['clone_ge12'] = M['final_clone_size'] >= 12
M['is_repro_check'] = M['series'].eq('S0')
M['revStore'] = M['revStore'].round(3); M['oxyRev'] = M['oxyRev'].round(3)
M['product'] = (M['revStore'] * M['oxyRev']).round(4)

# The same (scenario, revStore, oxyRev, pRevert, seed) can occur in two files: S3 repeats the
# revStore 0.33 / oxyRev 0.50 wound cell of the older wound series, but with the paired wound
# interval (see SERIES_S0_S3.md).  Where that happens the newer, paired run is kept.
key = ['scenario', 'revStore', 'oxyRev', 'pRevert', 'seed']
A = M[~M.is_repro_check].copy()
A['_older'] = A.series.eq('published')
dup = A.duplicated(key, keep=False)
if dup.any():
    print(f'NOTE: {int(dup.sum())//2} runs occur in two files; keeping the newer (paired-interval) version:',
          sorted(A[dup].source_file.unique()))
A = A.sort_values('_older').drop_duplicates(key, keep='first').drop(columns='_older')

# ---------- 3. provenance ----------
prov = (M.groupby('source_file').agg(series=('series', 'first'), runs=('seed', 'size'),
        scenarios=('scenario', lambda s: ', '.join(sorted(s.unique()))),
        revStore=('revStore', lambda s: ', '.join(map(str, sorted(s.unique())))),
        oxyRev=('oxyRev', lambda s: ', '.join(map(str, sorted(s.unique())))),
        pRevert=('pRevert', lambda s: ', '.join(map(str, sorted(s.unique())))),
        seeds=('seed', lambda s: f'{s.min()}-{s.max()}')).reset_index())

# ---------- 4. statistics per cell ----------
def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; den = 1 + z*z/n
    c = (p + z*z/(2*n)) / den; h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n)) / den
    return (100*(c-h), 100*(c+h))

rows = []
for (sc, r, o, pr), g in A.groupby(['scenario', 'revStore', 'oxyRev', 'pRevert']):
    n = len(g); k = int(g.established.sum()); lo, hi = wilson(k, n); t = g.clone_established_at_h.dropna()
    rows.append(dict(scenario=sc, revStore=r, oxyRev=o, pRevert=pr, product=round(r*o, 4), n_runs=n,
        established_pct=round(100*k/n, 1), ci95_low=round(lo, 1), ci95_high=round(hi, 1),
        survived_ge2_pct=round(100*g.survived_ge2.mean(), 1), clone_ge12_pct=round(100*g.clone_ge12.mean(), 1),
        n_established=k, median_time_h=t.median() if k else np.nan,
        p10_time_h=t.quantile(.1) if k else np.nan, p90_time_h=t.quantile(.9) if k else np.nan,
        median_final_clone=g.final_clone_size.median(), p90_final_clone=g.final_clone_size.quantile(.9),
        sources=', '.join(sorted(g.series.unique()))))
S = pd.DataFrame(rows).sort_values(['scenario', 'pRevert', 'revStore', 'oxyRev']).reset_index(drop=True)

# ---------- 5. save and print ----------
M.to_csv(os.path.join(OUT, 'master_runs.csv'), index=False)
S.to_csv(os.path.join(OUT, 'summary_cells.csv'), index=False)
prov.to_csv(os.path.join(OUT, 'provenance.csv'), index=False)
try:
    with pd.ExcelWriter(os.path.join(OUT, 'summary_cells.xlsx')) as w:
        S.to_excel(w, sheet_name='summary_cells', index=False); prov.to_excel(w, sheet_name='provenance', index=False)
except Exception as e:
    print('(xlsx not written:', type(e).__name__, ')')

print(f'{len(files)} files, {len(M)} runs in master_runs.csv '
      f'({int(M.is_repro_check.sum())} reproducibility-check runs left out of the statistics)')
print('\nWHAT COMES FROM WHERE'); print(prov.to_string(index=False))
nw = S[(S.scenario == 'none') & (S.pRevert == 0.001)]
print('\nNO WOUND, pRevert = 1/1000: established %, rows revStore x columns oxyRev')
print(nw.pivot(index='revStore', columns='oxyRev', values='established_pct').sort_index(ascending=False).to_string())
print('\nsummary_cells.csv:', len(S), 'cells')
