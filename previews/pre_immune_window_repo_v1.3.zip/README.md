# Pre-Immune Window of Monolayer Neoplasia — code and data

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.23065346.svg)](https://doi.org/10.5281/zenodo.23065346)

Simulation code and complete run data for *The Pre-Immune Window of Monolayer Neoplasia*
(Preface, Section 0, Parts I–II, Chapters 1–4). Everything reported in Chapters 1, 2 and 4
and in Section 2.6 of the paper can be reproduced from this repository.

## What is here

```
code/     the simulation engine, the batch runners, and the interactive bench
data/     the CSV files behind every figure and table in Chapters 1–2 and 4 (five published series, plus runs and 24 h trajectories of series S0–S3)
figures/  the figures as published, regenerated from data/ by code/make_figures.py
```

## The engine

The engine is an agent-based model of a monolayer epithelium on a hexagonal lattice of
76 × 79 = 6004 nodes. A cell owns 1–4 nodes; tension (the mean territory size of a cell
and its neighbours) governs the awakening of reserve cells and division; glucose diffuses
across the sheet and is consumed in proportion to each cell's metabolic state; division is
asymmetric. Two parameters distinguish the reverted lineage:

| Parameter | Meaning |
|---|---|
| `revStore` | ceiling of the reverted cell's glycogen store, as a fraction of a differentiated cell's |
| `oxyRev` | probability that a newborn reverted cell survives the one-time oxygen filter at birth; `1.0` disables the filter |

The engine is byte-for-byte identical in all three runner files, including the order of
random-number-generator calls, so runs are comparable across series. A second implementation
of the same model, in JavaScript, is included as an interactive bench — see below. The bench
is not required to reproduce anything here, and its geometry of cell occupancy differs, so it
is not a step-for-step replica of the Python runs.

## The runners

| File | Series it produced |
|---|---|
| `code/run_batch_oxygrid.py` | oxygen grid, no wound: `oxyRev` ∈ {0.30 … 0.50}, `revStore` = 0.33, 500 runs |
| `code/run_batch_oxygrid_wound.py` | oxygen grid under wounding: `oxyRev` ∈ {0.35 … 0.50} × {bounded, chronic}, 800 runs |
| `code/run_batch_missing.py` | runner for series S0–S5, described in `code/SERIES_S0_S3.md` and in Appendix A of the paper; adds 24-hour trajectory logging and a paired wound interval. All six series were run; results are in Section 2.6 of the paper. |

The bench and its driver are listed separately under *The interactive bench* below.

Each runner resumes from its own CSV, so an interrupted series can be continued by
launching the same command again.

```bash
pip install numba          # optional but strongly recommended; the pure-Python fallback is very slow
python code/run_batch_oxygrid.py
```

## Threshold sensitivity (no new runs)

`code/threshold_sensitivity.py` recomputes establishment at thresholds of 250, 500 and 1,000
cells from the 24 h trajectories of series S0–S5 (`data/missing_*_traj.csv`) and writes
`data/derived/threshold_sensitivity.csv`. At 500 it reproduces the engine's own flag for all
6,610 runs. The 2,500 earlier published runs have no trajectories; for the bounded-wounding
scenario the 1,000 threshold is not equivalent to a protocol with a 1,000 stop (wounding stops
at 500). See Appendix A.6 of the paper.

## The interactive bench

`code/epithelium_bench.html` is a single self-contained HTML file — no build step, no
dependencies. Open it in a browser and the sheet runs: pause, change any parameter, inflict
a wound, watch the reverted clone spread or fail. `code/bench_headless.js` drives the same
file in headless Chromium for a full 20,000 h horizon in about seven minutes.

```bash
npm i playwright
node code/bench_headless.js --store 0.33 --oxy 0.40 --hours 20000
```

`code/BENCH.md` documents the controls, the parameters used in the paper, how the bench
relates to the Python engine, and which passages of the notes inside the page are stale.

## The data

| File | Runs | revStore | oxyRev | Scenarios |
|---|---|---|---|---|
| `runs_series_baseline_033_2026-09.csv` | 300 | 0.33 | 1.0 (off) | none, bounded, chronic |
| `runs_series_glycogen_grid_none_2026-09.csv` | 300 | 0.20, 0.25, 0.30 | 1.0 (off) | none |
| `runs_series_glycogen_grid_wound_2026-09.csv` | 600 | 0.20, 0.25, 0.30 | 1.0 (off) | bounded, chronic |
| `runs_series_oxygrid_2026-08-29.csv` | 500 | 0.33 | 0.30–0.50 | none |
| `runs_series_oxygrid_wound_2026-09.csv` | 800 | 0.33 | 0.35–0.50 | bounded, chronic |
| `missing_S0_runs.csv` | 10 | 0.33 | 0.40, 1.0 | none (reproducibility check) |
| `missing_S1_runs.csv` | 1000 | 1.0 (plus 0.33 at 0.55, 0.60) | 0.30–0.60, 1.0 | none |
| `missing_S2_runs.csv` | 1600 | 0.50, 0.75 | 0.30–0.60, 1.0 | none |
| `missing_S3_runs.csv` | 1000 | 0.20, 0.25, 0.33, 0.50, 1.0 | 0.50 | bounded, chronic (paired) |
| `missing_S4A_runs.csv`, `missing_S4B_runs.csv` | 675 + 825 | 0.33, 0.50, 1.0 | 0.30, 0.40, 0.50, 0.60, 1.0 | none; `pRevert` 1/2000 and 1/500; 50 seeds (two halves of one series, run on two computers) |
| `missing_S5A_runs.csv`, `missing_S5B_runs.csv` | 675 + 825 | 0.20, 0.25, 0.30 | 0.30, 0.40, 0.50, 0.55, 0.60 | none; seeds 0–99 (two parts of one series, run on two computers) |
| `missing_S<n>_traj.csv` | — | — | — | 24 h trajectory of clone size and burden for each run of S0–S5 |

9110 runs in total (2500 published earlier, 6610 in S0–S5). `code/build_master.py` merges all run tables into one table with provenance columns and writes per-cell statistics (with 95% intervals) to `data/derived/`. One row per run. Common settings across every series: horizon 20,000 h,
establishment threshold 500 cells in the largest connected reverted cluster checked every
24 h, `pRevert` = 1/1000 per division, 100 seeds (0–99) per parameter combination. Wound
protocol where applicable: first wound at 1000 h, defect 200 cells, interval drawn per run
from {12, 24, 48} h; `bounded` stops wounding at the first threshold crossing, `chronic`
continues to the end of the horizon.

Columns worth noting: `final_clone_size` (largest connected reverted clone at the end),
`clone_established_at_h` (empty if the threshold was never crossed), `rev_total` (reversion
events), `rev_oxy_death` (would-be reverted cells culled by the oxygen filter at birth),
`rev_lost` (reverted cells lost through loss of niche), `final_density` (live cells / 6004).

## Figures

```bash
pip install pandas numpy matplotlib scipy
python code/make_figures.py
```

Regenerates all fifteen figures of the paper into `figures/` — `fig1_1` … `fig1_5`, `fig2_1` …
`fig2_9` and `fig4_1` — directly from `data/`. The script also prints the two statistics quoted
in Chapter 4: niche-loss mortality per surviving birth, 10.4% in runs where no clone became
established against 2.1% where one did, and a Spearman rank correlation of −0.55 between that
quantity and clone size. Reproducing those three numbers is the quickest check that the data
and the code in this repository belong together. It also prints the fit of the product relation
in Section 2.6 (ln t = 5.38 − 1.64 ln revStore − 1.64 ln oxyRev, R² = 0.89, 27 cells).

## Scope

The parameter grid is not a complete factorial exploration: `revStore` below 0.33 was run only with the
filter off, and wounding was run at `oxyRev` = 0.50 across the
glycogen range and at 0.35–0.50 for `revStore` = 0.33. Full glycogen with an active filter was
run in S1 (Section 2.6): the filter alone does not contain the clone at `revStore` ≥ 0.75. Numerical values
from these runs are coordinates within this parameterization, not calibrated quantities — the
model is intended to fix signs and orderings, and the paper states this explicitly (Chapter 4,
Rule 7).

## Authors

Dmitrochenko Y., M.D. — model, simulations, paper.
Demi S. L., Data Scientist — batch runs, data handling.

## Citation

Archived at Zenodo: [10.5281/zenodo.23065346](https://doi.org/10.5281/zenodo.23065346).
See `CITATION.cff`. If you use the data or the engine, please cite the paper and this
repository.

## License

Code: MIT (see `LICENSE`). Data (`data/`) and figures: CC BY 4.0.
