"""Recompute establishment at other thresholds from the 24 h trajectories (series S0-S5).

No new simulation runs are needed: data/missing_*_traj.csv holds the size of the largest
reverted clone every 24 h for the 6,610 runs of series S0-S5. A run is 'established at T'
if the largest clone exceeds T at any sample (strict '>' as in the engine). At T = 500 this
reproduces the engine's own establishment flag for every run (checked below).

Limits: the 2,500 runs published earlier have no trajectories; in the 'bounded' scenario
wounding stops when 500 is crossed, so T = 1000 is not equivalent to a protocol with a
1000 stop and should not be read for that scenario; samples are 24 h apart.

Usage:  python code/threshold_sensitivity.py        (run from the repository root)
Output: data/derived/threshold_sensitivity.csv
Requires: pandas, numpy
"""
import glob
import numpy as np
import pandas as pd

KEYS = ['series', 'scenario', 'revStore', 'oxyRev', 'pRevert', 'seed']
THRESHOLDS = (250, 500, 1000)

runs = pd.read_csv('data/derived/master_runs.csv')
runs = runs[runs.series != 'published']
traj = pd.concat([pd.read_csv(f) for f in sorted(glob.glob('data/missing_*_traj.csv'))],
                 ignore_index=True)
traj['series'] = traj['series'].astype(str)
traj['peak'] = traj.traj_clone.map(lambda s: np.fromstring(s, sep=';', dtype=int).max())

m = runs.merge(traj[KEYS + ['peak']], on=KEYS, how='inner', validate='1:1')
assert len(m) == len(runs), 'every S0-S5 run should have a trajectory'
for t in THRESHOLDS:
    m[f'est_{t}'] = m.peak > t
assert (m.est_500 == m.established).all(), 'threshold 500 must reproduce the engine flag'

cells = (m.groupby(['scenario', 'pRevert', 'revStore', 'oxyRev'])
           .agg(n_runs=('seed', 'size'),
                pct_established_gt250=('est_250', 'mean'),
                pct_established_gt500=('est_500', 'mean'),
                pct_established_gt1000=('est_1000', 'mean'))
           .reset_index())
for c in cells.columns[-3:]:
    cells[c] = (cells[c] * 100).round(1)
cells.to_csv('data/derived/threshold_sensitivity.csv', index=False)

base = cells[(cells.scenario == 'none') & (cells.pRevert == 0.001)]
print(f'{len(m)} runs reproduce the establishment flag at 500; baseline cells: {len(base)} '
      f'({int(base.n_runs.sum())} runs)')
print(base[['pct_established_gt250', 'pct_established_gt500', 'pct_established_gt1000']]
      .corr(method='spearman').round(3))
