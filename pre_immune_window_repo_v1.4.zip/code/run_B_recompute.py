"""
Recompute of the first-work grid in variant B (independent sisters), eliminating factor ElF.
STAGE 1 = all no-wound cells with oxyRev < 1 (5,500 runs). Same cells, same seeds as the first work.
(oxyRev = 1.0 = factor off: identical in A and B, NOT recomputed.  Wound series = stage 2, separate script.)

Engine: run_batch_siblings.py, sibMode=1 (each cell of a reverted-lineage pair survives independently
with Ps = (1+oxyRev)/2).  Run code/check_sibmode0.py first.

  python run_B_recompute.py --smoke                 (3 cells x 2 seeds, 2 h, pure Python OK)
  python run_B_recompute.py --part 1/2 --split 44,56   (computer 1 gets 44%, computer 2 56%)
Output: runs_B_stage1[_part<i>of<n>].csv  (columns of the first work + sibMode, Ps, mom_death).
Resume key (pRevert, revStore, oxyRev, seed): a re-run continues with the unfinished runs.
Jobs are ordered seed-by-seed, so an early stop leaves every cell with the same number of seeds.
"""
import os, sys, csv, time
from concurrent.futures import ProcessPoolExecutor, as_completed
import run_batch_siblings as R

SMOKE = '--smoke' in sys.argv
TARGET_HOURS = 2 if SMOKE else 20000
OXY_FULL = [0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
OXY_S4 = [0.30, 0.40, 0.50, 0.60]
OXY_S5 = [0.30, 0.40, 0.50, 0.55, 0.60]
# (pRevert, [revStore], [oxyRev], n_seeds)
CELLS = [
    (0.001,  [0.33, 0.50, 0.75, 1.0], OXY_FULL, 100),
    (0.001,  [0.20, 0.25, 0.30],      OXY_S5,   100),
    (0.0005, [0.33, 0.50, 1.0],       OXY_S4,   50),
    (0.002,  [0.33, 0.50, 1.0],       OXY_S4,   50),
]
if SMOKE:
    CELLS = [(0.001, [0.33], [0.6, 0.3], 2)]

PART, NPARTS, WEIGHTS = 1, 1, None
for i, a in enumerate(sys.argv):
    if a.startswith('--part'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        PART, NPARTS = (int(x) for x in v.split('/'))
    if a.startswith('--split'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        WEIGHTS = [int(x) for x in v.split(',')]
assert 1 <= PART <= NPARTS
if WEIGHTS: assert len(WEIGHTS) == NPARTS and sum(WEIGHTS) == 100

def owner_part(k):
    if WEIGHTS is None: return k % NPARTS
    slot, acc = (k * 37) % 100, 0
    for i, w in enumerate(WEIGHTS):
        acc += w
        if slot < acc: return i

OUT = 'runs_B_smoke.csv' if SMOKE else 'runs_B_stage1.csv'
if NPARTS > 1: OUT = OUT.replace('.csv', f'_part{PART}of{NPARTS}.csv')
SESSION_MINUTES = None

def key(pr, rs, oxy, seed):
    return (round(float(pr), 8), round(float(rs), 6), round(float(oxy), 6), int(seed))

if __name__ == '__main__':
    allj = []
    for seed in range(max(c[3] for c in CELLS)):
        for pr, rss, oxys, ns in CELLS:
            if seed >= ns: continue
            for rs in rss:
                for oxy in oxys:
                    allj.append((pr, rs, oxy, seed))
    print(f'{len(allj)} runs in the whole stage-1 grid')
    done = set()
    if os.path.exists(OUT):
        with open(OUT, newline='') as fh:
            for r in csv.DictReader(fh): done.add(key(r['pRevert'], r['revStore'], r['oxyRev'], r['seed']))
    jobs = []
    for k, (pr, rs, oxy, seed) in enumerate(allj):
        if owner_part(k) != PART - 1 or key(pr, rs, oxy, seed) in done: continue
        jobs.append(dict(run_id=k + 1, seed=seed, target_hours=TARGET_HOURS, scenario='none',
                         params=dict(lifeD=6.0, revStore=rs, oxyRev=oxy, pRevert=pr, sibMode=1, q2=1.0),
                         wound_start_h=None, wound_freq_h=None, wound_size=None, stop_threshold=500))
    print(f'part {PART}/{NPARTS}: {len(jobs)} runs left; numba={R.HAVE_NUMBA}')
    nw = os.cpu_count() or 1
    t0 = time.time(); writer = None
    new = not os.path.exists(OUT) or os.path.getsize(OUT) == 0
    with open(OUT, 'a', newline='') as f, ProcessPoolExecutor(max_workers=nw) as ex:
        for s in range(0, len(jobs), nw):
            if SESSION_MINUTES and (time.time() - t0) / 60 >= SESSION_MINUTES:
                print('session budget reached; re-run to resume'); break
            for fut in as_completed([ex.submit(R.run_one, **j) for j in jobs[s:s + nw]]):
                row = fut.result()
                row['Ps'] = (1 + row['oxyRev']) / 2
                if writer is None:
                    writer = csv.DictWriter(f, fieldnames=list(row.keys()))
                    if new: writer.writeheader()
                writer.writerow(row); f.flush()
                print(f"pR={row['pRevert']} rs={row['revStore']} oxy={row['oxyRev']} Ps={row['Ps']:.3f} "
                      f"seed={row['seed']} clone={row['final_clone_size']} est={row['clone_established_at_h']}")
