"""
Extension of the containment boundary at revStore 0.33 above the previously tested range (oxyRev 0.65-0.80).
Variants B (sibMode 1, sisters independent) and C (sibMode 3, sisters die together). No wound.
pRevert 0.001, horizon 20,000 h, seeds 0..99 (the same seeds as stage 1), establishment threshold 500 cells.
Grid: 4 oxyRev x 100 seeds x 2 variants = 800 runs.  Ps = (1+oxyRev)/2 = 0.825, 0.850, 0.875, 0.900.

Run code/check_sibmode0.py first (must print True).

  python run_ext_033.py --smoke                     (2 h, pure Python OK)
  python run_ext_033.py --part 1/2 --split 44,56    (computer 1 gets 44 %, computer 2 gets 56 %)
Output: runs_ext033[_part<i>of<n>].csv  (columns of stage 1 + sibMode, Ps, mom_death).
Resume key (sibMode, oxyRev, seed): a re-run continues with the unfinished runs.
Jobs go seed by seed, so an early stop leaves every cell with the same number of seeds.
"""
import os, sys, csv, time
from concurrent.futures import ProcessPoolExecutor, as_completed
import run_batch_siblings as R

SMOKE = '--smoke' in sys.argv
TARGET_HOURS = 2 if SMOKE else 20000
PR, RS = 0.001, 0.33
OXY = [0.65, 0.70, 0.75, 0.80]
MODES = [1, 3]          # 1 = B, 3 = C
NSEEDS = 100
if SMOKE: OXY, NSEEDS = [0.65], 2

PART, NPARTS, WEIGHTS = 1, 1, None
for i, a in enumerate(sys.argv):
    if a.startswith('--part'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        PART, NPARTS = (int(x) for x in v.split('/'))
    if a.startswith('--split'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        WEIGHTS = [int(x) for x in v.split(',')]
assert 1 <= PART <= NPARTS
if WEIGHTS: assert len(WEIGHTS) == NPARTS and sum(WEIGHTS) == 100

def owner_part(k):
    if WEIGHTS is None: return k % NPARTS
    slot, acc = (k * 37) % 100, 0
    for i, w in enumerate(WEIGHTS):
        acc += w
        if slot < acc: return i

OUT = 'runs_ext033_smoke.csv' if SMOKE else 'runs_ext033.csv'
if NPARTS > 1: OUT = OUT.replace('.csv', f'_part{PART}of{NPARTS}.csv')

def key(mode, oxy, seed):
    return (int(mode), round(float(oxy), 6), int(seed))

if __name__ == '__main__':
    allj = [(m, oxy, seed) for seed in range(NSEEDS) for oxy in OXY for m in MODES]
    print(f'{len(allj)} runs in the whole extension')
    done = set()
    if os.path.exists(OUT):
        with open(OUT, newline='') as fh:
            for r in csv.DictReader(fh): done.add(key(r['sibMode'], r['oxyRev'], r['seed']))
    jobs = []
    for k, (m, oxy, seed) in enumerate(allj):
        if owner_part(k) != PART - 1 or key(m, oxy, seed) in done: continue
        jobs.append(dict(run_id=k + 1, seed=seed, target_hours=TARGET_HOURS, scenario='none',
                         params=dict(lifeD=6.0, revStore=RS, oxyRev=oxy, pRevert=PR, sibMode=m, q2=1.0),
                         wound_start_h=None, wound_freq_h=None, wound_size=None, stop_threshold=500))
    print(f'part {PART}/{NPARTS}: {len(jobs)} runs left; numba={R.HAVE_NUMBA}')
    nw = os.cpu_count() or 1
    t0 = time.time(); writer = None
    new = not os.path.exists(OUT) or os.path.getsize(OUT) == 0
    with open(OUT, 'a', newline='') as f, ProcessPoolExecutor(max_workers=nw) as ex:
        for s in range(0, len(jobs), nw):
            for fut in as_completed([ex.submit(R.run_one, **j) for j in jobs[s:s + nw]]):
                row = fut.result()
                row['Ps'] = (1 + row['oxyRev']) / 2
                if writer is None:
                    writer = csv.DictWriter(f, fieldnames=list(row.keys()))
                    if new: writer.writeheader()
                writer.writerow(row); f.flush()
                print(f"mode={row.get('sibMode')} oxy={row['oxyRev']} Ps={row['Ps']:.3f} "
                      f"seed={row['seed']} clone={row['final_clone_size']} est={row['clone_established_at_h']}")
