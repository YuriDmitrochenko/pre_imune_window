"""
Regression check: the maternal mode of the sibling-fate engine (run_batch_siblings.py, sibMode = 0)
must reproduce the engine of Chapters 1-2 (run_batch_oxygrid.py) step by step.
Runs both for 1,500 steps (seed 7, pRevert 0.5, oxyRev 0.6) and compares the counters, cell ownership,
lineage, state arrays and clone burden. The sibling-fate engine has one extra counter (the 12th, deaths of the
mother, 0 in mode 0); the first 11 counters of the two engines are compared. Prints True if all are identical.   python code/check_sibmode0.py
"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_batch_oxygrid as O
import run_batch_siblings as R
P = dict(pRevert=0.5, oxyRev=0.6)
a = O.Sim(7, dict(P)); b = R.Sim(7, dict(P, sibMode=0))
for _ in range(1500):
    a.advance(); b.advance()
ok = (np.array_equal(a.counters[:11], b.counters[:11]) and b.counters[11] == 0 and np.array_equal(a.owner, b.owner)
      and np.array_equal(a.clin, b.clin) and np.array_equal(a.cst, b.cst) and a.burden() == b.burden())
print(ok)
sys.exit(0 if ok else 1)
