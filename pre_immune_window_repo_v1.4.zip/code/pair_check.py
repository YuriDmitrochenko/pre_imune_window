"""
Check of the sibling-fate rule at scale.  Every division of a reverted-lineage cell (clin == 1) is a "pair":
the mother and the new daughter.  The engine counts how often (a) both cells were lost, (b) exactly one,
(c) none, and the script compares the shares with the formulas (s = (1 + oxyRev)/2, p = oxyRev):

  variant A (sibMode 0)  both: 0          one: 1 - p          none: p
  variant B (sibMode 1)  both: (1-s)^2    one: 2 s (1-s)      none: s^2
  variant C (sibMode 3)  both: 1 - s      one: 0              none: s

The founding reversion (a normal cell's daughter becoming reverted for the first time) is NOT a pair; it uses
p = oxyRev in all variants and is not counted here.
Engine: run_batch_siblings_pairs.py = run_batch_siblings.py + three extra counters (the random stream is unchanged).
High reversion rate (pRevert 0.5) is used only to get many pairs quickly; the rule does not depend on it.

  python pair_check.py --smoke                        (3 runs, 1500 steps; with numba seconds, pure Python about 10 minutes; pairs must be > 0; delete pair_check_smoke.csv afterwards)
  python pair_check.py --part 1/2 --split 44,56       (computer 1 / computer 2)
  python pair_check.py --summary                      (after both parts are in this folder: merges and prints the table)
Output: pair_check_runs[_part<i>of<n>].csv   one row per run; pair_check_summary.csv   one row per cell.
"""
import os, sys, csv, math, glob, time
from concurrent.futures import ProcessPoolExecutor, as_completed

SMOKE = '--smoke' in sys.argv
STEPS = 1500 if SMOKE else 2000
NSEEDS = 1 if SMOKE else 200
MODES = [0, 1, 3]
OXY = [0.60] if SMOKE else [0.30, 0.40, 0.50, 0.60, 0.80]      # s = 0.65, 0.70, 0.75, 0.80, 0.90
PREV = 0.5

PART, NPARTS, WEIGHTS = 1, 1, None
for i, a in enumerate(sys.argv):
    if a.startswith('--part'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        PART, NPARTS = (int(x) for x in v.split('/'))
    if a.startswith('--split'):
        v = a.split('=')[1] if '=' in a else sys.argv[i + 1]
        WEIGHTS = [int(x) for x in v.split(',')]
if WEIGHTS: assert len(WEIGHTS) == NPARTS and sum(WEIGHTS) == 100

def owner_part(k):
    if WEIGHTS is None: return k % NPARTS
    slot, acc = (k * 37) % 100, 0
    for i, w in enumerate(WEIGHTS):
        acc += w
        if slot < acc: return i

def expected(mode, oxy):
    s = 0.5 * (1 + oxy); p = oxy
    if mode == 0: return (0.0, 1 - p, p)
    if mode == 1: return ((1 - s) ** 2, 2 * s * (1 - s), s * s)
    return (1 - s, 0.0, s)

def job(a):
    import run_batch_siblings_pairs as E
    mode, oxy, seed, steps = a
    sim = E.Sim(seed, dict(pRevert=PREV, oxyRev=oxy, sibMode=mode))
    for _ in range(steps): sim.advance()
    c = sim.counters
    return dict(sibMode=mode, oxyRev=oxy, Ps=0.5 * (1 + oxy), seed=seed, steps=steps,
                pairs=int(c[12]), both=int(c[13]), one=int(c[14]), none=int(c[12] - c[13] - c[14]))

def summary():
    import pandas as pd
    fs = sorted(glob.glob('pair_check_runs*.csv'))
    d = pd.concat([pd.read_csv(f) for f in fs], ignore_index=True).drop_duplicates(['sibMode', 'oxyRev', 'seed'])
    g = d.groupby(['sibMode', 'oxyRev'])[['pairs', 'both', 'one', 'none']].sum().reset_index()
    rows = []; worst = 0.0; bad_struct = 0
    for _, r in g.iterrows():
        e = expected(int(r.sibMode), r.oxyRev); n = int(r.pairs)
        row = dict(sibMode=int(r.sibMode), oxyRev=r.oxyRev, Ps=0.5 * (1 + r.oxyRev), runs=int(((d.sibMode == r.sibMode) & (d.oxyRev == r.oxyRev)).sum()), pairs=n)
        for name, k, ex in (('both', r.both, e[0]), ('one', r.one, e[1]), ('none', r.none, e[2])):
            obs = k / n if n else float('nan')
            row[name + '_obs'] = round(obs, 4); row[name + '_exp'] = round(ex, 4)
            if n < 1000:
                row[name + '_z'] = ''
            elif 0 < ex < 1:
                z = (obs - ex) / math.sqrt(ex * (1 - ex) / n); row[name + '_z'] = round(z, 2); worst = max(worst, abs(z))
            else:
                row[name + '_z'] = ''
                if k != (0 if ex == 0 else n): bad_struct += 1
        rows.append(row)
    S = pd.DataFrame(rows); S.to_csv('pair_check_summary.csv', index=False)
    print(S.to_string(index=False))
    print(f'\n{len(d)} runs, {int(g.pairs.sum())} pairs; largest |z| = {worst:.2f}; structural-zero violations = {bad_struct}')
    if int(g.pairs.min()) < 1000:
        print('TOO FEW PAIRS in some cell (< 1000): nothing can be concluded yet')
    else:
        print('OK' if (bad_struct == 0 and worst < 3.5) else 'LOOK AT THE TABLE: |z| >= 3.5 or a structural zero was violated')

if __name__ == '__main__':
    if '--summary' in sys.argv:
        summary(); sys.exit(0)
    allj = [(m, o, sd, STEPS) for sd in range(NSEEDS) for o in OXY for m in MODES]
    OUT = 'pair_check_smoke.csv' if SMOKE else 'pair_check_runs.csv'
    if NPARTS > 1: OUT = OUT.replace('.csv', f'_part{PART}of{NPARTS}.csv')
    done = set()
    if os.path.exists(OUT):
        with open(OUT, newline='') as fh:
            for r in csv.DictReader(fh): done.add((int(r['sibMode']), round(float(r['oxyRev']), 6), int(r['seed'])))
    jobs = [a for k, a in enumerate(allj) if owner_part(k) == PART - 1 and (a[0], round(a[1], 6), a[2]) not in done]
    print(f'{len(allj)} runs in the whole check; part {PART}/{NPARTS}: {len(jobs)} left')
    import run_batch_siblings_pairs as E
    print('numba =', E.HAVE_NUMBA)
    nw = os.cpu_count() or 1; writer = None
    new = not os.path.exists(OUT) or os.path.getsize(OUT) == 0
    with open(OUT, 'a', newline='') as f, ProcessPoolExecutor(max_workers=nw) as ex:
        for s in range(0, len(jobs), nw * 4):
            for fut in as_completed([ex.submit(job, j) for j in jobs[s:s + nw * 4]]):
                row = fut.result()
                if writer is None:
                    writer = csv.DictWriter(f, fieldnames=list(row.keys()))
                    if new: writer.writeheader()
                writer.writerow(row); f.flush()
    print('done:', OUT)
