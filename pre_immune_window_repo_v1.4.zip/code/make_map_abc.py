"""
Figure 2.10: share of runs with an established clone (no wounding) in the three variants of how the two sister
cells share the exposure: A maternal (master_runs.csv), B independent and C coupled (data/siblings/).
Rows: revStore; columns: s = (1 + oxyRev)/2 (0.65 ... 0.80; 1.0 = no filter, identical in all variants).
Black outline: containment zone (establishment <= 1%).   python code/make_map_abc.py
Writes figures/fig2_10.png (English) and figures/fig2_10_ru.png (Russian).
"""
import os
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
m=pd.read_csv(os.path.join(ROOT,'data','derived','master_runs.csv'))
B=pd.read_csv(os.path.join(ROOT,'data','siblings','runs_B_stage1.csv')); C=pd.read_csv(os.path.join(ROOT,'data','siblings','runs_C_stage1.csv'))
RS=[1.0,0.75,0.5,0.33,0.30,0.25,0.20]; OX=[0.30,0.40,0.50,0.55,0.60,1.0]
base=m[(m.scenario=='none')&(m.pRevert==0.001)]
def frac(df,rs,ox):
    g=df[(df.revStore.round(3)==rs)&(df.oxyRev.round(3)==ox)]
    return 100*g.clone_established_at_h.notna().mean() if len(g) else np.nan
def grid(df):
    G=np.full((len(RS),len(OX)),np.nan)
    for i,rs in enumerate(RS):
        for j,ox in enumerate(OX):
            src=df if ox<1 else base          # filter off: identical in A, B, C
            G[i,j]=frac(src,rs,ox)
    return G
A=base[base.series!='S0']
Gs={'A':grid(A),'B':grid(B[B.pRevert==0.001]),'C':grid(C[C.pRevert==0.001])}
for k,v in Gs.items(): print(k); print(np.round(v).astype(int))
T={'en':dict(
  title={'A':'A. The mother always survives; only the daughter is exposed','B':'B. The two sisters are exposed independently','C':'C. The two sisters survive or die together'},
  y='Glycogen reserve\n(fraction of a mature cell)',x='Survival of a reverted cell at division, s  →  the filter weakens',off='1.0\n(no filter)',
  zone='containment zone: establishment ≤ 1%',head='Share of runs in which the clone became established (no wounding), 100 runs per cell'),
 'ru':dict(
  title={'A':'A. Мать всегда выживает; фактору подвергается только дочь','B':'B. Обе сестры подвергаются независимо','C':'C. Обе сестры выживают или гибнут вместе'},
  y='Запас гликогена\n(доля от зрелой клетки)',x='Выживание ревертной клетки при делении, s  →  фильтр слабее',off='1,0\n(без фильтра)',
  zone='зона удержания: закрепление ≤ 1 %',head='Доля прогонов с закрепившимся клоном (без ранения), 100 прогонов на ячейку')}
XS=['0.650','0.700','0.750','0.775','0.800']
def draw(lang,fn):
    t=T[lang]; fig,axs=plt.subplots(3,1,figsize=(7.2,8.6),dpi=200)
    from matplotlib.colors import LinearSegmentedColormap
    cmap=LinearSegmentedColormap.from_list('c',[(0,'#006837'),(0.2,'#5cb85f'),(0.28,'#8acc67'),(0.5,'#fee08b'),(0.75,'#fdb166'),(1,'#cc2727')])
    for ax,k in zip(axs,'ABC'):
        G=Gs[k]; ax.set_xlim(0,len(OX)); ax.set_ylim(len(RS),0)
        for i in range(len(RS)):
            for j in range(len(OX)):
                v=G[i,j]; ax.add_patch(Rectangle((j,i),1,1,fc=cmap(v/100) if v==v else '#ddd',ec='white',lw=2))
                s=('%d%%'%round(v)) if lang=='en' else ('%d %%'%round(v))
                ax.text(j+.5,i+.5,s,ha='center',va='center',fontsize=8.5,fontweight='bold',color=('white' if (v<=5 or v>=90) else '#222'))
        zone=(G<=1.0)
        for i in range(len(RS)):
            for j in range(len(OX)):
                if not zone[i,j]: continue
                for (di,dj,seg) in ((-1,0,((j,i),(j+1,i))),(1,0,((j,i+1),(j+1,i+1))),(0,-1,((j,i),(j,i+1))),(0,1,((j+1,i),(j+1,i+1)))):
                    ni,nj=i+di,j+dj
                    if not(0<=ni<len(RS) and 0<=nj<len(OX)) or not zone[ni,nj]:
                        ax.plot([seg[0][0],seg[1][0]],[seg[0][1],seg[1][1]],color='#222',lw=3,solid_capstyle='projecting')
        ax.set_yticks([i+.5 for i in range(len(RS))]); ax.set_yticklabels([('%.2f'%r).replace('.',',') if lang=='ru' else '%.2f'%r for r in RS] ,fontsize=10)
        ax.set_yticklabels([ ('1.0' if r==1.0 else '%.2f'%r) if lang=='en' else ('1,0' if r==1.0 else ('%.2f'%r).replace('.',',')) for r in RS],fontsize=10)
        ax.set_xticks([j+.5 for j in range(len(OX))])
        xl=[x.replace('.',',') if lang=='ru' else x for x in XS]+[t['off']]
        ax.set_xticklabels(xl,fontsize=10)
        ax.tick_params(length=0)
        for sp in ax.spines.values(): sp.set_visible(False)
        ax.set_title(t['title'][k],loc='left',fontsize=11.5,fontweight='bold',color='#222')
        ax.set_ylabel(t['y'],fontsize=9.5)
    axs[2].set_xlabel(t['x'],fontsize=10,labelpad=2)
    fig.text(0.02,0.982,t['head'],fontsize=11,color='#222',ha='left')
    fig.text(0.15,0.008,t['zone'],fontsize=9.5,fontweight='bold',color='#222',ha='left')
    fig.subplots_adjust(left=0.15,right=0.985,top=0.925,bottom=0.105,hspace=0.52)
    fig.savefig(fn); plt.close(fig)
draw('en',os.path.join(ROOT,'figures','fig2_10.png')); draw('ru',os.path.join(ROOT,'figures','fig2_10_ru.png'))
