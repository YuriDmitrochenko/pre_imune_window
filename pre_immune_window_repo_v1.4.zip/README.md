# Pre-Immune Window of Monolayer Neoplasia — code and data

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.23065346.svg)](https://doi.org/10.5281/zenodo.23065346)

Simulation code and complete run data for *The Pre-Immune Window of Monolayer Neoplasia*
(Preface, Section 0, Parts I–II, Chapters 1–4). Everything reported in Chapters 1, 2 and 4
and in Section 2.6 of the paper can be reproduced from this repository.

## What is here

```
code/     the simulation engine, the batch runners, and the interactive bench
data/     the CSV files behind every figure and table in Chapters 1–2 and 4 (five published series, plus runs and 24 h trajectories of series S0–S3)
figures/  the figures as published, regenerated from data/ by code/make_figures.py (fig2_10 by code/make_map_abc.py)
```

Version 1.4 adds the sibling-fate variants B and C (Section 2.6, Appendix A.7): the engine with a
switch for the rule, the three runner scripts, 11,800 further runs in `data/siblings/` and Figure 2.10.

## The engine

The engine is an agent-based model of a monolayer epithelium on a hexagonal lattice of
76 × 79 = 6004 nodes. A cell owns 1–4 nodes; tension (the mean territory size of a cell
and its neighbours) governs the awakening of reserve cells and division; glucose diffuses
across the sheet and is consumed in proportion to each cell's metabolic state; division is
asymmetric. Two parameters distinguish the reverted lineage:

| Parameter | Meaning |
|---|---|
| `revStore` | ceiling of the reverted cell's glycogen store, as a fraction of a differentiated cell's |
| `oxyRev` | probability that a newborn reverted cell survives the one-time oxygen filter at birth; `1.0` disables the filter |

The engine is byte-for-byte identical in the three original runner files, including the order of
random-number-generator calls, so runs are comparable across series. `code/run_batch_siblings.py` is the same
engine with one added switch, `sibMode`, for how the two sister cells of a reverted-lineage pair share the
exposure (see *Sibling-fate variants*); its mode 0 reproduces the original engine step by step
(`code/check_sibmode0.py`, 1,500 steps: the first 11 counters, cell ownership, lineage, state arrays and clone burden; prints `True`). A second implementation
of the same model, in JavaScript, is included as an interactive bench — see below. The bench
is not required to reproduce anything here, and its geometry of cell occupancy differs, so it
is not a step-for-step replica of the Python runs.

## The runners

| File | Series it produced |
|---|---|
| `code/run_batch_oxygrid.py` | oxygen grid, no wound: `oxyRev` ∈ {0.30 … 0.50}, `revStore` = 0.33, 500 runs |
| `code/run_batch_oxygrid_wound.py` | oxygen grid under wounding: `oxyRev` ∈ {0.35 … 0.50} × {bounded, chronic}, 800 runs |
| `code/run_batch_missing.py` | runner for series S0–S5, described in `code/SERIES_S0_S3.md` and in Appendix A of the paper; adds 24-hour trajectory logging and a paired wound interval. All six series were run; results are in Section 2.6 of the paper. |

| `code/run_batch_siblings.py` | engine with the sibling-fate switch `sibMode` (0 maternal = A, 1 independent = B, 3 coupled = C; 2 was written and dropped); runner functions as in the other files |
| `code/run_B_recompute.py` | variant B: the 5,500 runs of the no-wound grid with `oxyRev` < 1, same cells and seeds as the first work (`--part i/n --split w1,w2` divides the work between computers) |
| `code/run_C_recompute.py` | the same grid in variant C |
| `code/run_ext_033.py` | extension at `revStore` = 0.33, `oxyRev` 0.65, 0.70, 0.75, 0.80, variants B and C, seeds 0–99: 800 runs |
| `code/check_sibmode0.py` | regression check: mode 0 of the sibling-fate engine equals the engine of the first work |
| `code/make_map_abc.py` | Figure 2.10, the three heatmaps (A, B, C) |
| `code/pair_check.py`, `code/run_batch_siblings_pairs.py` | check of the sibling-fate rule against its formulas (Appendix A.8): the engine counts, at every division of a reverted-lineage cell, whether both cells, exactly one or none were lost; `--summary` merges the parts and prints the comparison. The engine file is `run_batch_siblings.py` plus three counters (the random stream is unchanged) |

The bench and its driver are listed separately under *The interactive bench* below.

Each runner resumes from its own CSV, so an interrupted series can be continued by
launching the same command again.

```bash
pip install numba          # optional but strongly recommended; the pure-Python fallback is very slow
python code/run_batch_oxygrid.py
```

## Sibling-fate variants

The eliminating factor acts at division with survival probability s = (1 + `oxyRev`)/2 per cell (0.5 ≤ s ≤ 1;
s = 1 is no filter). How the fates of the two sister cells of a reverted-lineage pair are coupled is an
assumption of the model, so three variants were computed (Section 2.6 and Appendix A.7 of the paper):

| `sibMode` | Variant | Rule | Both cells lost |
|---|---|---|---|
| 0 | A, maternal | the mother always survives; the daughter passes with p = `oxyRev` = 2s − 1 | never |
| 1 | B, independent | each cell survives with s | (1 − s)² |
| 3 | C, coupled | one draw per division: both survive with s or both die | 1 − s |

The expected number of survivors per pair is 2s in all three; only the variance differs. The sibling-fate
tables are in `data/siblings/` (the same columns as the other run tables, plus `sibMode`, `Ps` = s and
`mom_death`) and are not merged into `master_runs.csv`, which holds variant A. Every run goes the full
20,000 h, so run time does not depend on the outcome. The drivers write their output into the current directory
and resume from it, so run them from `data/siblings/`, e.g.

```bash
cd data/siblings
python ../../code/check_sibmode0.py
python ../../code/run_ext_033.py --smoke          # 4 runs, 2 h; delete runs_ext033_smoke.csv afterwards
python ../../code/run_ext_033.py --part 1/2 --split 44,56
```

The wound series (S3 and Chapter 2) were not recomputed in B and C.

The rule itself is checked in `code/pair_check.py` (Appendix A.8 of the paper): at every division of a reverted-lineage
cell the engine counts whether both cells, exactly one or none were lost, and the shares are compared with the formulas
(A: 0, 1 − p, p; B: (1 − s)², 2s(1 − s), s²; C: 1 − s, 0, s). The founding reversion of a cell is not a pair; in all
variants it passes the filter with probability p = `oxyRev`. Run from `data/siblings/`:

```bash
cd data/siblings
python ../../code/pair_check.py --summary      # merges pair_check_runs*.csv and prints OK / LOOK AT THE TABLE
```

## Threshold sensitivity (no new runs)

`code/threshold_sensitivity.py` recomputes establishment at thresholds of 250, 500 and 1,000
cells from the 24 h trajectories of series S0–S5 (`data/missing_*_traj.csv`) and writes
`data/derived/threshold_sensitivity.csv`. At 500 it reproduces the engine's own flag for all
6,610 runs. The 2,500 earlier published runs have no trajectories; for the bounded-wounding
scenario the 1,000 threshold is not equivalent to a protocol with a 1,000 stop (wounding stops
at 500). See Appendix A.6 of the paper.

## The interactive bench

`code/epithelium_bench.html` is a single self-contained HTML file — no build step, no
dependencies. Open it in a browser and the sheet runs: pause, change any parameter, inflict
a wound, watch the reverted clone spread or fail. `code/bench_headless.js` drives the same
file in headless Chromium for a full 20,000 h horizon in about seven minutes.

```bash
npm i playwright
node code/bench_headless.js --store 0.33 --oxy 0.40 --hours 20000
```

`code/BENCH.md` documents the controls, the parameters used in the paper, how the bench
relates to the Python engine, and which passages of the notes inside the page are stale.

## The data

| File | Runs | revStore | oxyRev | Scenarios |
|---|---|---|---|---|
| `runs_series_baseline_033_2026-09.csv` | 300 | 0.33 | 1.0 (off) | none, bounded, chronic |
| `runs_series_glycogen_grid_none_2026-09.csv` | 300 | 0.20, 0.25, 0.30 | 1.0 (off) | none |
| `runs_series_glycogen_grid_wound_2026-09.csv` | 600 | 0.20, 0.25, 0.30 | 1.0 (off) | bounded, chronic |
| `runs_series_oxygrid_2026-08-29.csv` | 500 | 0.33 | 0.30–0.50 | none |
| `runs_series_oxygrid_wound_2026-09.csv` | 800 | 0.33 | 0.35–0.50 | bounded, chronic |
| `missing_S0_runs.csv` | 10 | 0.33 | 0.40, 1.0 | none (reproducibility check) |
| `missing_S1_runs.csv` | 1000 | 1.0 (plus 0.33 at 0.55, 0.60) | 0.30–0.60, 1.0 | none |
| `missing_S2_runs.csv` | 1600 | 0.50, 0.75 | 0.30–0.60, 1.0 | none |
| `missing_S3_runs.csv` | 1000 | 0.20, 0.25, 0.33, 0.50, 1.0 | 0.50 | bounded, chronic (paired) |
| `missing_S4A_runs.csv`, `missing_S4B_runs.csv` | 675 + 825 | 0.33, 0.50, 1.0 | 0.30, 0.40, 0.50, 0.60, 1.0 | none; `pRevert` 1/2000 and 1/500; 50 seeds (two halves of one series, run on two computers) |
| `missing_S5A_runs.csv`, `missing_S5B_runs.csv` | 675 + 825 | 0.20, 0.25, 0.30 | 0.30, 0.40, 0.50, 0.55, 0.60 | none; seeds 0–99 (two parts of one series, run on two computers) |
| `missing_S<n>_traj.csv` | — | — | — | 24 h trajectory of clone size and burden for each run of S0–S5 |
| `siblings/runs_B_stage1.csv` | 5500 | 0.20–1.0 | 0.30–0.60 | none; variant B (`sibMode` 1); `pRevert` 1/1000 (4300 runs), 1/2000 and 1/500 (600 each, 50 seeds) |
| `siblings/runs_C_stage1.csv` | 5500 | 0.20–1.0 | 0.30–0.60 | none; variant C (`sibMode` 3); same cells and seeds as B |
| `siblings/runs_ext033.csv` | 800 | 0.33 | 0.65, 0.70, 0.75, 0.80 | none; variants B and C, 400 runs each (extension of the grid above the earlier range); run in two parts on two computers with numba |
| `siblings/pair_check_runs.csv` | 3000 | — | 0.30, 0.40, 0.50, 0.60, 0.80 | rule check: variants A, B, C × 5 `oxyRev` × 200 seeds × 2,000 steps at `pRevert` 0.5; columns `pairs`, `both`, `one`, `none` per run (2,284,817 pairs in all) |
| `siblings/provenance_siblings.csv` | — | — | — | what comes from where for the three tables above |
| `derived/summary_ABC.csv` | — | — | — | per cell: establishment and median time in A, B and C, with Fisher P for B vs C and A vs C |
| `derived/pair_check_summary.csv` | — | — | — | per cell of the rule check: observed and expected shares, z-values |
| `derived/summary_ext033.csv` | — | — | — | per cell of the extension: established runs, 95% interval, median time |

9110 runs in variant A (2500 published earlier, 6610 in S0–S5) and 11,800 further runs in variants B and C (2 × 5,500 plus 800 in the extension), 20,910 in all, and 3,000 runs of the rule check described under *Sibling-fate variants*. `code/build_master.py` merges all run tables into one table with provenance columns and writes per-cell statistics (with 95% intervals) to `data/derived/`. One row per run. Common settings across every series: horizon 20,000 h,
establishment threshold 500 cells in the largest connected reverted cluster checked every
24 h, `pRevert` = 1/1000 per division, 100 seeds (0–99) per parameter combination. Wound
protocol where applicable: first wound at 1000 h, defect 200 cells, interval drawn per run
from {12, 24, 48} h; `bounded` stops wounding at the first threshold crossing, `chronic`
continues to the end of the horizon.

Columns worth noting: `final_clone_size` (largest connected reverted clone at the end),
`clone_established_at_h` (empty if the threshold was never crossed), `rev_total` (reversion
events), `rev_oxy_death` (would-be reverted cells culled by the oxygen filter at birth),
`rev_lost` (reverted cells lost through loss of niche), `final_density` (live cells / 6004).

## Figures

```bash
pip install pandas numpy matplotlib scipy
python code/make_figures.py
```

Regenerates the fifteen figures of the paper into `figures/` — `fig1_1` … `fig1_5`, `fig2_1` …
`fig2_9` and `fig4_1` — directly from `data/`. The script also prints the two statistics quoted
in Chapter 4: niche-loss mortality per surviving birth, 10.4% in runs where no clone became
established against 2.1% where one did, and a Spearman rank correlation of −0.55 between that
quantity and clone size. Reproducing those three numbers is the quickest check that the data
and the code in this repository belong together. It also prints the fit of the product relation
in Section 2.6 (ln t = 5.38 − 1.64 ln revStore − 1.64 ln oxyRev, R² = 0.89, 27 cells).

`python code/make_map_abc.py` draws Figure 2.10 (`figures/fig2_10.png`, Russian version `fig2_10_ru.png`) from
`data/derived/master_runs.csv` and `data/siblings/`.

## Scope

The parameter grid is not a complete factorial exploration: `revStore` below 0.33 was run only with the
filter off, and wounding was run at `oxyRev` = 0.50 across the
glycogen range and at 0.35–0.50 for `revStore` = 0.33. The sibling-fate variants B and C were run on the no-wound grid only. Full glycogen with an active filter was
run in S1 (Section 2.6): the filter alone does not contain the clone at `revStore` ≥ 0.75. Numerical values
from these runs are coordinates within this parameterization, not calibrated quantities — the
model is intended to fix signs and orderings, and the paper states this explicitly (Chapter 4,
Rule 7).

## Authors

Dmitrochenko Y., M.D. — model, simulations, paper.
Demi S. L., Data Scientist — batch runs, data handling.

## Citation

Archived at Zenodo: [10.5281/zenodo.23065346](https://doi.org/10.5281/zenodo.23065346).
See `CITATION.cff`. If you use the data or the engine, please cite the paper and this
repository.

## License

Code: MIT (see `LICENSE`). Data (`data/`) and figures: CC BY 4.0.
