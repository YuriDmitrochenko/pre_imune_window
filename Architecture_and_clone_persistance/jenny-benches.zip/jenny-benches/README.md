# Jenny1–6 simulation benches

**Authors:** Dmitrochenko Y, MD · Demi Sarah Lana, Data Scientist
**Date:** 07.11.2026

Six browser simulations ("stands") of a single-layer, self-renewing epithelium, used to find the conditions under which a rare abnormal clone dies out, stalls or spreads. Each stand is one self-contained HTML page: a hexagonal sheet of about 6,000 grid points (76 × 79, 20 µm each, roughly 1.5 × 1.6 mm of tissue) advanced in 3-minute steps, a live picture of the sheet, and sliders that change the rules while it runs. Each stand keeps everything in the one before it and adds one mechanism.

They are an exploratory bench, not a published or validated model: every number they produce is a property of these rules on this grid, not a measurement in tissue. They serve as the two-dimensional control arm of the hypothesis *Architectural coupling of elimination and resource access in metabolically dependent epithelial clones*.

## How to run

Open any `jennyN.html` file in a web browser. No installation or server is needed. The pages load their fonts from Google Fonts; without internet access they fall back to system fonts and still run.

## The six stands

| File | Mechanism added |
| --- | --- |
| `jenny1.html` | Base sheet: shedding, spreading, wake-on-stretch division, glucose supply; reverted line with 1:100 terminal commitment ("reverted commitment" version) |
| `jenny2.html` | A dormant reverted cell waits without limit and draws 10 % of baseline glucose |
| `jenny3.html` | The oxygen hazard applies to both cells of every reverted division (critical point s = 1/2) |
| `jenny4.html` | Mobilization window; spontaneous memoryless waking; death only after a committed failed attempt |
| `jenny5.html` | Boundary contest at the clone–normal interface; extrusion of dormant cells under sustained majority pressure |
| `jenny6.html` | Inherited defect load; critical cells need awake, sub-critical neighbours; amplification limit; niche supply |

## Known limitations

- All six stands are two-dimensional; none models a stratified or compact three-dimensional lesion.
- No stand produces or consumes debris: a dead cell's node simply becomes free.
- Extrusion is counted as elimination; basal extrusion with survival is not represented.
- Cooperation in Jenny6 is binary (awake/asleep), not a measured flux.
- Calibrations do not carry across stands (oxygen survival changes meaning at Jenny3; Jenny6's niche supply raises the effective reserve fraction to about 0.36).
